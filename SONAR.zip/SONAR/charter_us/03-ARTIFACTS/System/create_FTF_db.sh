#!/bin/bash

echo "Creating FTF DB"
if [ -e /var/opt/mediation/MMDB/fm_db_FTF/data ]; then
        echo "DB already created"
elif [ -e /home/emmuser/Update/CXP9036929_R2N/MM_UTILITY ]; then
cd /home/emmuser/Update/CXP9036929_R2N/
sudo ./MM_UTILITY << EOF
2
3
3
FM
FTF
5479
mmsuper
/var/opt/mediation/MMDB
y
x
EOF
else
        echo "MM_UTILITY not found"
        exit 0
fi

echo "Updating .pgpass"
if [[ ! `sudo grep fm_db_FTF /var/lib/pgsql/.pgpass` ]]; then
        sudo echo "localhost:5479:fm_db_FTF:mmsuper:mmsuper" >> /var/lib/pgsql/.pgpass
fi

echo "Creating FTF tables"
#sudo -u postgres psql -d fm_db_FTF -p 5479 -U mmsuper -f tableScript_FTF.sql