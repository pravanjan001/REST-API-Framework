--
-- Name: tc_def1; Type: TABLE; Schema: mmsuper; Owner: mmsuper
--

CREATE TABLE tc_def1 (
    id integer NOT NULL,
    system_under_test character varying NOT NULL,
    test_suite character varying NOT NULL,
    test_scenario character varying NOT NULL,
    testcase_id character varying NOT NULL,
    testcase_def character varying,
    prerequisite character varying,
    asn1field character varying NOT NULL,
    rule character varying NOT NULL
);


ALTER TABLE tc_def1 OWNER TO mmsuper;

--
-- Name: tc_def1 tc_def1_pkey; Type: CONSTRAINT; Schema: mmsuper; Owner: mmsuper
--

ALTER TABLE ONLY tc_def1
    ADD CONSTRAINT tc_def1_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

--
-- Name: testcasereport1; Type: TABLE; Schema: mmsuper; Owner: mmsuper
--

CREATE TABLE testcasereport1 (
    system character varying,
    module character varying,
    scenario character varying,
    testcaseid character varying,
    result character varying,
    reason character varying,
    filename character varying,
    islasttc character varying,
    recindex character varying,
    refrecindex character varying,
    remarks character varying,
    execution_time timestamp with time zone DEFAULT now()
);


ALTER TABLE testcasereport1 OWNER TO mmsuper;

--
-- PostgreSQL database dump complete
--
