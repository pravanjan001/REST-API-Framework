#!/usr/bin/perl

# Usage: configxmltosrc.pl <config_xml_file> <output-dir>

use strict;
use warnings;

use XML::LibXML;
use File::Path;
use File::Basename;

sub getTimestamp {
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
  my $nice_timestamp = sprintf ( "%04d%02d%02d%02d%02d%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec);
  return $nice_timestamp;
}

sub getNodeType {
  my $_node = $_[0];
  
  if($_node->findnodes('.//neDisk')->size > 0) { return "neDisk"; };
  if($_node->findnodes('.//neFTPClient')->size > 0) { return "neFTPClient"; };
  if($_node->findnodes('.//neRPC')->size > 0) { return "neRPC"; };
  if($_node->findnodes('.//neTFTP')->size > 0) { return "neTFTP"; };
  if($_node->findnodes('.//neRadius')->size > 0) { return "neRadius"; };
  if($_node->findnodes('.//neGTPprim')->size > 0) { return "neGTPprim"; };
  if($_node->findnodes('.//neSNMP')->size > 0) { return "neSNMP"; };
  if($_node->findnodes('.//neDatabase')->size > 0) { return "neDatabase"; };
  if($_node->findnodes('.//neDynamic')->size > 0) { return "neDynamic"; };
  if($_node->findnodes('.//neSFTPClient')->size > 0) { return "neSFTPClient"; };
  if($_node->findnodes('.//generator')->size > 0) { return "generator"; };
  if($_node->findnodes('.//neIntercomClient')->size > 0) { return "neIntercomClient"; };
  if($_node->findnodes('.//neBSCS')->size > 0) { return "neBSCS"; };
  if($_node->findnodes('.//neStream')->size > 0) { return "neStream"; };
  if($_node->findnodes('.//neDiskOptimizedIO')->size > 0) { return "neDiskOptimizedIO"; };
  if($_node->findnodes('.//formatter')->size > 0) { return "formatter"; };
  if($_node->findnodes('.//rating')->size > 0) { return "rating"; };
  if($_node->findnodes('.//filter')->size > 0) { return "filter"; };
  if($_node->findnodes('.//matcher')->size > 0) { return "matcher"; };
  if($_node->findnodes('.//scalableConsolidator')->size > 0) { return "scalableConsolidator"; };
  if($_node->findnodes('.//dbMatcher')->size > 0) { return "dbMatcher"; };
  if($_node->findnodes('.//dupcheck')->size > 0) { return "dupcheck"; };
  if($_node->findnodes('.//dbDupCheck')->size > 0) { return "dbDupCheck"; };
  if($_node->findnodes('.//fileDupCheck')->size > 0) { return "fileDupCheck"; }
  if($_node->findnodes('.//activeAlarm')->size > 0) { return "activeAlarm"; };
  if($_node->findnodes('.//multiNE')->size > 0) { return "multiNE"; };
  if($_node->findnodes('.//logPoint')->size > 0) { return "logPoint"; };
  if($_node->findnodes('.//scalableDupCheck')->size > 0) { return "scalableDupCheck"; };
  if($_node->findnodes('.//ppsDisk')->size > 0) { return "ppsDisk"; };
  if($_node->findnodes('.//ppsFTP')->size > 0) { return "ppsFTP"; };
  if($_node->findnodes('.//ppsRPC')->size > 0) { return "ppsRPC"; };
  if($_node->findnodes('.//ppsDatabase')->size > 0) { return "ppsDatabase"; };
  if($_node->findnodes('.//ppsDynamic')->size > 0) { return "ppsDynamic"; };
  if($_node->findnodes('.//ppsRadius')->size > 0) { return "ppsRadius"; };
  if($_node->findnodes('.//ppsSFTP')->size > 0) { return "ppsSFTP"; };
  if($_node->findnodes('.//ppsTrashcan')->size > 0) { return "ppsTrashcan"; };
  if($_node->findnodes('.//ppsIntercomClient')->size > 0) { return "ppsIntercomClient"; };
  if($_node->findnodes('.//ppsBSCS')->size > 0) { return "ppsBSCS"; };
  if($_node->findnodes('.//ppsALB')->size > 0) { return "ppsALB"; };
  if($_node->findnodes('.//ppsDiskOptimizedIO')->size > 0) { return "ppsDiskOptimizedIO"; };
  if($_node->findnodes('.//dvrf')->size > 0) { return "dvrf"; };
  if($_node->findnodes('.//drviewer')->size > 0) { return "drviewer"; };
  if($_node->findnodes('.//tcl')->size > 0) { return "tcl"; };
  if($_node->findnodes('.//cpp')->size > 0) { return "cpp"; };
  if($_node->findnodes('.//java')->size > 0) { return "java"; };
}


# Check parameters
die "Usage: $0 <full-path-xml-config-file> <base-path>\n" if @ARGV < 2;

my $inputfilename = $ARGV[0];
my $baseinputfilename = basename($inputfilename);
my $basedir = $ARGV[1];
my $dom = XML::LibXML->load_xml(location => $inputfilename, no_blanks => 1);
my $root = $dom->documentElement;

#my ($configname) = $root->findvalue('./name') . "_" . $root->findvalue('./versionInfo');
my ($configname) = $root->findvalue('./name');

# Adds versionInfo to dir name
#my $configver = getTimestamp();
#if($root->findnodes('./versionInfo')->size > 0) {
#  ($configver) = $root->findvalue('./versionInfo');
#}

#my $_nodepath = $basedir . "/" . $configname . "/" . $configver . "/nodes";
#my $_pgpath = $basedir . "/" . $configname . "/" . $configver . "/processGroups";
#my $_ppath = $basedir . "/" . $configname . "/" . $configver . "/paths";
#my $_orgpath = $basedir . "/" . $configname . "/" . $configver . "/originalXML";
my $_nodepath = $basedir . "/" . $configname . "/nodes";
my $_pgpath = $basedir . "/" . $configname . "/processGroups";
my $_ppath = $basedir . "/" . $configname . "/paths";
#my $_orgpath = $basedir . "/" . $configname . "/originalXML";

my $_cfggitdir = $basedir . "/" . $configname . "/.git";

if(! -d "$basedir/$configname") {
  mkpath([$_nodepath, $_pgpath, $_ppath]);
}

# Save original XML file
#unless(open OUTNODEFILE, '>', "$_orgpath/$baseinputfilename") {
#  die "\nUnable to create $_orgpath/$baseinputfilename\n";
#}

#print OUTNODEFILE $root->toString(1);
#close OUTNODEFILE;

# List of items to check whether they were deleted
# Existing items are overwritten
my @listOfNodesFromConfig;
my @listOfPGroupsFromConfig;
my @listOfPathsFromConfig;

# Nodes
foreach my $node ($root->findnodes('./nodes/Node')) {
	my $_type = "";
	my $_nodename = "";
  my $_nodeid = "";
	my $nodeFilename = "";	

	my ($nodetype) = $node->findnodes('./type');
  
  $_type = getNodeType($node);

	$_nodename = $node->findvalue('./name');
  $_nodeid = $node->findvalue('./id');
	
	$nodeFilename = $_nodepath . "/" . $_type . "_" . $_nodeid . "_" . $_nodename . ".xml";
	$nodeFilename =~ s/[^A-Za-z0-9\-\.\_\/]//g;
  
  push(@listOfNodesFromConfig, $nodeFilename);

	#say "type :", $_type;
	#say "nodename :", $_nodename;
	#say "output filename : ", $nodeFilename;
	
  if(-e $nodeFilename) {
    unless(open OUTNODEFILE, '+<', $nodeFilename) {
      die "\nUnable to create $nodeFilename\n";
    }
  } else {
    unless(open OUTNODEFILE, '>', $nodeFilename) {
      die "\nUnable to create $nodeFilename\n";
    }  
  }

	print OUTNODEFILE $node->toString(1);
	close OUTNODEFILE;
}

if ($root->findnodes("./nodes")->size > 0) {
  my ($_nodes) = $root->findnodes("./nodes");
  $root->removeChild($_nodes);
};

# Process groups
foreach my $node ($root->findnodes('./processGroups/ProcessGroup')) {
	my $_type = "";
	my $_nodename = "";
	my $nodeFilename = "";	

	$_nodename = $node->findvalue('./name');
	
	$nodeFilename = $_pgpath . "/processGroup_" . $_nodename . ".xml";
	$nodeFilename =~ s/[^A-Za-z0-9\-\.\_\/]//g;
  
  push(@listOfPGroupsFromConfig, $nodeFilename);

	#say "type :", $_type;
	#say "nodename :", $_nodename;
	#say "output filename : ", $nodeFilename;
  
  if(-e $nodeFilename) {
    unless(open OUTNODEFILE, '+<', $nodeFilename) {
      die "\nUnable to create $nodeFilename\n";
    }
  } else {
    unless(open OUTNODEFILE, '>', $nodeFilename) {
      die "\nUnable to create $nodeFilename\n";
    }  
  }

	print OUTNODEFILE $node->toString(1);
	close OUTNODEFILE;
}
if ($root->findnodes("./processGroups")->size > 0) {
  my ($_nodes) = $root->findnodes("./processGroups");
  $root->removeChild($_nodes);
};

# Paths
foreach my $node ($root->findnodes('./paths/Path')) {
	my $_nodename = "";
	my $nodeFilename = "";	

	$_nodename = "from_" . $node->findvalue('./fromID') . "_" . $node->findvalue('./fromName') . "_to_" . $node->findvalue('./toID') . "_" . $node->findvalue('./toName');
	
	$nodeFilename = $_ppath . "/path_" . $_nodename . ".xml";
	$nodeFilename =~ s/[^A-Za-z0-9\-\.\_\/]//g;
  
  push(@listOfPathsFromConfig, $nodeFilename);

	#say "type :", $_type;
	#say "nodename :", $_nodename;
	#say "output filename : ", $nodeFilename;
	
  if(-e $nodeFilename) {
    unless(open OUTNODEFILE, '+<', $nodeFilename) {
      die "\nUnable to create $nodeFilename\n";
    }
  } else {
    unless(open OUTNODEFILE, '>', $nodeFilename) {
      die "\nUnable to create $nodeFilename\n";
    }  
  }

	print OUTNODEFILE $node->toString(1);
	close OUTNODEFILE;
}

if ($root->findnodes("./paths")->size > 0) {
  my ($_nodes) = $root->findnodes("./paths");
  $root->removeChild($_nodes);
};

# Root node
my $nodeFilename =  $basedir . "/" . $configname . "/Application_" . $configname . ".xml";
$nodeFilename =~ s/[^A-Za-z0-9\-\.\_\/]//g;

if(-e $nodeFilename) {
  unless(open OUTNODEFILE, '+<', $nodeFilename) {
    die "\nUnable to create $nodeFilename\n";
  }
} else {
  unless(open OUTNODEFILE, '>', $nodeFilename) {
    die "\nUnable to create $nodeFilename\n";
  }  
}

print OUTNODEFILE $root->toString(1);
close OUTNODEFILE;

# Check whether any node was removed from this version, and delete it from the repo
opendir my $_nodedir, $_nodepath or die "Can't open directory $_nodepath";
my @_nodefiles =  grep { !/^\./ && /.*xml/  } readdir $_nodedir;
closedir $_nodedir;

foreach my $nodefile (@_nodefiles) {
  my $fullpathfile = $_nodepath . "/" . $nodefile;
  if(! grep(/$nodefile$/, @listOfNodesFromConfig)) {
    print "Removing file not present in new version: $fullpathfile\n";
    system("rm -f $fullpathfile");
  }
}

opendir my $_pgdir, $_pgpath or die "Can't open directory $_pgpath";
my @_pgfiles = grep { !/^\./ && /.*xml/  } readdir $_pgdir;
closedir $_pgdir;

foreach my $pgfile (@_pgfiles) {
  my $fullpathfile = $_pgpath . "/" . $pgfile;
  if(! grep(/$pgfile$/, @listOfPGroupsFromConfig)) {
    print "Removing file not present in new version: $fullpathfile\n";
    system("rm -f $fullpathfile");
  }
}

opendir my $_pdir, $_ppath or die "Can't open directory $_ppath";
my @_pfiles = grep { !/^\./ && /.*xml/  } readdir $_pdir;
closedir $_pdir;

foreach my $pfile (@_pfiles) {
  my $fullpathfile = $_ppath . "/" . $pfile;
  if(! grep(/$pfile$/, @listOfPathsFromConfig)) {
    print "Removing file not present in new version: $fullpathfile\n";
    system("rm -f $fullpathfile");
  }
}

print "\nUpdated directory $configname.\n";
exit 0;

