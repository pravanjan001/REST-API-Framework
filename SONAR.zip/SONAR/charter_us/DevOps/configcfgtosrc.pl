#!/usr/bin/perl

# Usage: configcfgtosrc.pl <config_cfg_file> <output-dir>

use strict;
use warnings;

use Config::IniFiles;
use File::Path;
use File::Basename;

sub getTimestamp {
  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
  my $nice_timestamp = sprintf ( "%04d%02d%02d%02d%02d%02d", $year+1900,$mon+1,$mday,$hour,$min,$sec);
  return $nice_timestamp;
}

sub getNodeId {
  my ($var) = @_;
  
  my ($a, $b, $c) = split(/:/, $var);
  
  $c =~ s/([a-fA-F0-9][a-fA-F0-9])/hex($1)/eg;
  $c =~ s/[^0-9]//g;
  return $c; 
}

sub convertToAscii {
  my ($value) = @_;
  
  $value =~ s/([a-fA-F0-9][a-fA-F0-9])/chr(hex($1))/eg;
  
  return $value; 
}

sub convertToHex {
  my ($value) = @_;
  my $result = "";
  
  $result .= sprintf("%2.2x",ord($_)) for (split //,$value);
  
  return $result;   
}

# Text parameters that will be generated in separate file
my @separateParameters = ("TrafficControlModel", 
						"ModuleWrapperEditorProfile.textEditorString",
						"HttpBackendEditorProfile.textEditorString",
						"DiameterEditorProfile.textEditorString",
						"ValueRouterEditorProfile.textEditorString",
						"JavaFormatterEditorProfile.textEditorString",
						"FormatterEditorProfile.textEditorString",
						"DatabaseLookupEditorProfile.textEditorString",
						"RadiusEditorProfile.textEditorString",
						"ChargingProxyDefinitionProfile.textEditorString",
						"WebServicesBETreeProfile.tree",
						"RestWebServicesBETreeProfile.tree",
						"JMSBETreeProfile.tree",
						"ASN1Profile.tree",
						"WebServicesFETreeProfile.tree",
						"RestWebServicesFETreeProfile.tree",
						"JMSFETreeProfile.tree",
						"JobProfile.description");

# Specific file extensions for separate files
my %separateParams_extensions = ("TrafficControlModel" => ".par", 
						"ModuleWrapperEditorProfile.textEditorString" => ".par",
						"HttpBackendEditorProfile.textEditorString" => ".par",
						"DiameterEditorProfile.textEditorString" => ".par",
						"ValueRouterEditorProfile.textEditorString" => ".java",
						"JavaFormatterEditorProfile.textEditorString" => ".java",
						"FormatterEditorProfile.textEditorString" => ".xml",
						"DatabaseLookupEditorProfile.textEditorString" => ".sql",
						"RadiusEditorProfile.textEditorString" => ".par",
						"ChargingProxyDefinitionProfile.textEditorString" => ".par",
						"WebServicesBETreeProfile.tree" => ".par",
						"RestWebServicesBETreeProfile.tree" => ".par",
						"JMSBETreeProfile.tree" => ".par",
						"ASN1Profile.tree" => ".par",
						"WebServicesFETreeProfile.tree" => ".par",
						"RestWebServicesFETreeProfile.tree" => ".par",
						"JMSFETreeProfile.tree" => ".par",
						"JobProfile.description" => ".par");
						
# Check parameters
die "Usage: $0 <full-path-cfg-config-file> <base-path>\n" if @ARGV < 2;

my $inputfilename = $ARGV[0];
my $baseinputfilename = basename($inputfilename);
my $basedir = $ARGV[1];

# Load cfg file
my $cfg =  Config::IniFiles->new( -file => $inputfilename);

my $cfg_name = $cfg->val("OVERALL_PROPERTIES", "name");

my $_nodepath = $basedir . "/" . $cfg_name . "/nodes";
my $_cfggitdir = $basedir . "/" . $cfg_name . "/.git";

if(! -d "$basedir/$cfg_name") {
  mkpath($_nodepath);
}

my $mainFilename = $basedir . "/" . $cfg_name . "/Application_" . $cfg_name . ".cfg";

# Save SYSTEM and OVERALL_PROPERTIES in main base file
my $src_main = new Config::IniFiles();

my @src_systems_sect = $cfg->Parameters("SYSTEMS");
$src_main->AddSection("SYSTEMS");
for my $src_systems_param (@src_systems_sect) {
  $src_main->newval("SYSTEMS", $src_systems_param, $cfg->val("SYSTEMS", $src_systems_param));
}

my @src_overall_sect = $cfg->Parameters("OVERALL_PROPERTIES");
$src_main->AddSection("OVERALL_PROPERTIES");
for my $src_overall_param (@src_overall_sect) {
  # Check if parameter needs to be in a separate file - only for hex text for now
  if(grep(/^$src_overall_param$/, @separateParameters)) {
	my $sepFilename = $basedir . "/" . $cfg_name . "/" . "Application_OVERALL_PROPERTIES#" . $src_overall_param . $separateParams_extensions{$src_overall_param};
	$sepFilename =~ s/[^A-Za-z0-9\-\.\_\/\#]//g;
	my $sepValue = convertToAscii($cfg->val("OVERALL_PROPERTIES", $src_overall_param));
	
	unless(open OUTSEPFILE, '>', $sepFilename) {
      die "\nUnable to create $sepFilename\n";
    }
	
	print OUTSEPFILE $sepValue;
	close OUTSEPFILE;
  } else {
    $src_main->newval("OVERALL_PROPERTIES", $src_overall_param, $cfg->val("OVERALL_PROPERTIES", $src_overall_param));
  }
}

$cfg->DeleteSection("SYSTEMS");
$cfg->DeleteSection("OVERALL_PROPERTIES");

$src_main->WriteConfig($mainFilename) or die "Error writing $mainFilename";

# Parse each section and generate separate files
my @cfg_sections = $cfg->Sections;

for my $cfg_section (@cfg_sections) {
  my $src_node = new Config::IniFiles();  
  
  my $sec_type = $cfg->val($cfg_section, "type"); 
  my $sec_id = getNodeId($cfg->val($cfg_section, "id")); 

  my $nodeFilename = $_nodepath . "/" . $sec_id . "_" . $sec_type . "_" . $cfg_section . ".cfg";
  $nodeFilename =~ s/[^A-Za-z0-9\-\.\_\/\#]//g;
   
  my @src_node_sect = $cfg->Parameters($cfg_section);
  for my $src_node_param (@src_node_sect) {  
    # Check if parameter needs to be in a separate file - only for hex text for now
    if(grep(/^$src_node_param$/, @separateParameters)) {
      my $sepFilename = $_nodepath . "/" . $sec_id . "_" . $sec_type . "_" . $cfg_section . "#" . $src_node_param . $separateParams_extensions{$src_node_param};
	  $sepFilename =~ s/[^A-Za-z0-9\-\.\_\/\#]//g;
      my $sepValue = convertToAscii($cfg->val($cfg_section, $src_node_param));
      
      unless(open OUTSEPFILE, '>', $sepFilename) {
        die "\nUnable to create $sepFilename\n";
      }
    
      print OUTSEPFILE $sepValue;
      close OUTSEPFILE;
    } else {  
      $src_node->newval($cfg_section, $src_node_param, $cfg->val($cfg_section, $src_node_param));
    }    
    $src_node->WriteConfig($nodeFilename) or die "Error writing $nodeFilename";
  }
}

print "\nUpdated directory $basedir/$cfg_name.\n";
exit 0;




