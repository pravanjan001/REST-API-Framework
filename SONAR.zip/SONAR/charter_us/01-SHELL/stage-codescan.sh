#!/bin/sh

sonar-scanner

if [ "$?" -ne 0 ]
then
  info "Successfully finished the codescan phase..."
  exit 1
fi


