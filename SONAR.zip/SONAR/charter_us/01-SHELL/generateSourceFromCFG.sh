#!/bin/bash

# Get settings
_DIR="${BASH_SOURCE%/*}"

if [ $# -lt 2 ]
then
  echo "Usage: $0 <full-path-CFG-file> <full-path-output-dir>"
  exit 1
fi

if [ ! -e ${1} ]
then
  echo "${1}: not found"
  exit 1
fi

XMLFILE=${1}
SRCOUTPUTDIR=${2}

# Check whether the CFG file is valid (a config one)
if ! grep -q 'OVERALL_PROPERTIES' ${XMLFILE}
then
  echo "${XMLFILE} is not a valid configuration file."
  exit 1
fi

# Create output dir if it doesn't exist
mkdir -p ${SRCOUTPUTDIR}

../DevOps/configcfgtosrc.pl ${XMLFILE} ${SRCOUTPUTDIR}
if [ $? -ne 0 ]
then
  echo "Error processing ${XMLFILE}"
  exit 1
fi

echo "Source code generated sucessfully."
