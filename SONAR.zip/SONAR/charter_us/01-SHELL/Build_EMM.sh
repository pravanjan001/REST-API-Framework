#!/bin/bash
# **********************************************************************
#             File : EMM_Build.sh
#
# Copyright (c) 2008 Ericsson AB, Sweden.
# All rights reserved.
# The Copyright to the computer program(s) herein is the property of
# Ericsson AB, Sweden. The program(s) may be used and/or copied with
# the written permission from Ericsson AB or in accordance with the
# terms and conditions stipulated in the agreement/contract under
# which the program(s) have been supplied.
#
# Author                        Date            Comment
# eluirub                       2019-12-02      Creation
#
# **********************************************************************


function info {
    echo "INFO : $(date +'%Y-%m-%d %H:%M:%S %Z') $*"
}

function fatal {
    echo "ERROR: $(date +'%Y-%m-%d %H:%M:%S %Z') $*"
    exit 1
}

function deployConfig {
_SERVER=$1
_COLLECTION=$2
_CONFIG=$3
_CONFIGPATH=$4

#Stopping Configuration
info "$clipath/cli startcommand $EMM_USERNAME $EMM_PASSWORD $_MANAGER_IP:$_MANAGER_PORT stop -coll $_COLLECTION -config $_CONFIG -s $_SERVER"
$clipath/cli startcommand $EMM_USERNAME $EMM_PASSWORD $_MANAGER_IP:$_MANAGER_PORT stop -coll $_COLLECTION -config $_CONFIG -s $_SERVER
if [ $? != 0 ];
then
  fatal "Stopping EMM Configuration Failed"
  exit 0
else
  info "Stopping EMM Configuration successfull. Continue with Deployment"
fi

info "$clipath/cli startcommand $EMM_USERNAME $EMM_PASSWORD $_MANAGER_IP:$_MANAGER_PORT unprovision -coll $_COLLECTION -config $_CONFIG -s $_SERVER"
$clipath/cli startcommand $EMM_USERNAME $EMM_PASSWORD $_MANAGER_IP:$_MANAGER_PORT unprovision -coll $_COLLECTION -config $_CONFIG -s $_SERVER
if [ $? != 0 ];
then
  fatal "Unprovision EMM Configuration Failed"
  exit 0
else
  info "Unprovision EMM Configuration successfull. Continue with Deployment"
fi

info "$clipath/cli startcommand $EMM_USERNAME $EMM_PASSWORD $_MANAGER_IP:$_MANAGER_PORT importconfig -coll $_COLLECTION -configpath $_CONFIGPATH -dep -r"
$clipath/cli startcommand $EMM_USERNAME $EMM_PASSWORD $_MANAGER_IP:$_MANAGER_PORT importconfig -coll $_COLLECTION -configpath $_CONFIGPATH -dep -r
if [ $? != 0 ];
then
  fatal "Import EMM Configuration Failed"
  exit 0
else
  info "Import EMM Configuration successfull. Continue with Deployment"
fi

info "$clipath/cli startcommand $EMM_USERNAME $EMM_PASSWORD $_MANAGER_IP:$_MANAGER_PORT provision -coll $_COLLECTION -config $i -s $_SERVER"
$clipath/cli startcommand $EMM_USERNAME $EMM_PASSWORD $_MANAGER_IP:$_MANAGER_PORT provision -coll $_COLLECTION -config $_CONFIG -s $_SERVER
if [ $? != 0 ];
then
  fatal "Provision EMM Configuration Failed"
  exit 0
else
  info "Provision EMM Configuration successfull. Continue with Deployment"
fi

info "$clipath/cli startcommand $EMM_USERNAME $EMM_PASSWORD $_MANAGER_IP:$_MANAGER_PORT start -config $_CONFIG -s $_SERVER"
#$clipath/cli startcommand $EMM_USERNAME $EMM_PASSWORD $_MANAGER_IP:$_MANAGER_PORT start -config $_CONFIG -s $_SERVER
if [ $? != 0 ];
then
  fatal "Starting EMM Configuration Failed"
  exit 0
else
  info "Starting EMM Configuration successfull. Deployment completed successfully"
fi

#curl -u$ArtifactoryUser:$ArtifactoryKey -T $i "$ArtifactoryURL/EMM/Config/$i"

}

function update_hosts
{
        external_hosts=$1

        # Check if there are new external hosts to be added
        [[ -e ./new_hosts ]] && rm -f ./new_hosts
        diff -w /etc/hosts $external_hosts |grep ">" | cut -c3- > ./new_hosts
        # Update /etc/hosts file
        if [ -s ./new_hosts ]; then
                backupdate=`date +"%Y%m%d%H%M%S"`
                info "Creating backup for existing /etc/hosts file:"
                sudo cp -pR /etc/hosts /etc/hosts.${backupdate}

                # Delete existing entries if already present (for instance if an e1xternal host has changed the ip)
                cp -pR /etc/hosts ./hosts.tmp;
                cat ./new_hosts | while read ip hostname; do
                        grep -s " $hostname$" ./hosts.tmp && sed "/ $hostname$/d" ./hosts.tmp > 1;
                        if [ -f 1 ]; then mv 1 ./hosts.tmp; rm -fR 1;fi
                done;
                sudo cp -pR ./hosts.tmp /etc/hosts

                # append new hosts
                sudo cat ./new_hosts >> /etc/hosts
                info "File /etc/hosts updated"
        else
                info "No new hosts to be updated in File /etc/hosts"
        fi

}

function update_lookups
{
        new_lookup=$1
        old_lookup=$2

        if [[ -f $old_lookup ]]; then
                diff $old_lookup $new_lookup ; if [ $? -eq 1 ] ; then
                        info "Updating new version for $old_lookup"
                        backupdate=`date +"%Y%m%d%H%M%S"`
                        cp -p $old_lookup $old_lookup.${backupdate} # Backup existing lookup data
                        cp -pR $new_lookup $old_lookup; # Replace with new lookup data
                else
                        info "Skipping $old_lookup, it contains same data"
                fi
        else
                info "Creating new lookup file $new_lookup"
                cp -pR $new_lookup $old_lookup; # Copying new lookup data
        fi
}

###############################################3
# Main
info "Starting ...."
info "Setting up working directories Configs, Lookups and System configuration"
#system_dir=../config/System/
#lookup_dir=../../config/Lookups/
#config_dir=../../config/Configs/
system_dir=./System/
lookup_dir=../Lookups/
config_dir=../Configs/

info "#########################"
info "Loading enviroment variables from env_info.config"
source env_info.config

if [ -f "/opt/test/shell/version.txt" ]
then
  info "version txt file present"
  rm -rf /opt/test/shell/version.txt
else
  info "version txt file is not present"
fi

cd ${system_dir}
info "#########################"
info "Updating hosts from `pwd`"
if [[ -e external_hosts ]]; then
        info "Updating hosts from  ${system_dir}/external_hosts into /etc/hosts"
        update_hosts external_hosts
else
        pwd
        ls ${system_dir}
        info "No external_hosts has been found in ${system_dir}"
fi

info "#########################"
info "Unzipping files from `pwd` in root dir"
for f in *.zip ;do
        if [[ -e $f ]]; then
                dir=`pwd`
                cd /
                info "Unzipping ${f} in root directory"
                sudo unzip ${dir}/${f}
                cd $dir
        else
                info "No zip file has been found in ${system_dir}"
        fi
done

info "#########################"
info "Executing shell scripts in `pwd`"
for f in *.sh ;do
        if [[ -e $f ]]; then
                info "Executing ${f}"
                chmod +x ${f}
                sudo ./${f}
        else
                info "No shell scripts in ${system_dir} to be executed"
        fi
done

info "#########################"
cd ${lookup_dir}
info "Updating lookups from `pwd`"
[[ -d ${_LOOKUP_DIR} ]] || mkdir ${_LOOKUP_DIR} # Create target lookup directory if it doesn't exist
for f in *; do
        if [[ -e $f ]]; then
                info "Updating ${f} in ${_LOOKUP_DIR}"
                update_lookups ${f} ${_LOOKUP_DIR}/${f}
        else
                info "No lookup files in ${lookup_dir} to be updated"
        fi
done

info "#########################"
cd ${config_dir}
info "Processing Configuration files from `pwd`"
for f in *; do
{
        if [[ ! -e $f ]]; then
        {
                info "No config files in ${config_dir} to be updated"
                exit 0;
        }
        fi

        info "#########################"
        info "Processing $f configuration file"
        if [[ $f == *.xml ]];then
        {
                info "Getting name and versionInfo tags from $f xml file"
                name=`sed -n 's/<name>\(.*\)<\/name>/\1/p' $f | head -1|awk -F'[][]' '{print $3}'`
                versionInfo=`awk '/<\/versionInfo>/ { print }' $f`
                #if [[ $versionInfo =~ "<versionInfo>" ]];then
                        # full tag
                #        versionInfo=`echo $versionInfo |awk -F'[][]' '{print $3}'`
                #else
                #        # broken tag
                #        versionInfo=`echo $versionInfo |awk -F'[][]' '{print $1}' | sed 's/^ //'`
                #fi
        }
        elif [[ $f == *.cfg ]]; then
        {
                info "Getting name and versionInfo tags from $f cfg file"
                name=`grep "^name" $f | cut -d "=" -f2`
                versionInfo=`grep "^JobProfile.description" $f | cut -d "=" -f2 | xxd -r -p`
        }
        elif [[ $f == *.car ]]; then
        {
                fatal "File ${f} not supported, please use .xml (for F&E) or .cfg (for OLM)"
                                exit 1;
        }
        fi
        info "Config name = \"$name\", versioInfo = \"$versionInfo\""

        info "Looking for ${name} config in topology: $_TOPOLOGY"
        IFS=';' read -r -a servers <<< $_TOPOLOGY

        found=0
        for server in "${servers[@]}"
        do
        {
                config=`echo $server | cut -d "/" -f 2`
                collection=`echo $server | cut -d ":" -f 2 |  cut -d "/" -f 1`
                server=`echo $server | cut -d ":" -f 1`
                if [[ $name == $config ]]; then
                {
                        found=1;
                        info "Found $config in logical server = ${server} and collection = ${collection}"

                        info "Getting latest version for config $config in target enviroment"
                        info "$clipath/cli startcommand ${EMM_USERNAME} ${EMM_PASSWORD} $_MANAGER_IP:$_MANAGER_PORT lcv -coll $collection --config $config"
                        ${clipath}/cli startcommand ${EMM_USERNAME} ${EMM_PASSWORD} $_MANAGER_IP:$_MANAGER_PORT lcv -coll $collection --config $config |grep "^\[" |tail -1 | awk -F'[][]' '{print $2}' > /opt/test/shell/version.txt
                        version=`cat /opt/test/shell/version.txt`

                        if [[ ! -z $version ]];then
                        {
                                # IMPORTANT: psql will connect only if postgres home directory contains .pgpass file with "localhost:5445:mgrdb:mmsuper:<pwd>"

                                echo -e "\pset format unaligned \n select value from mm_configversion where versionid='${version}' and configid = (select configid from mm_configuration where name='${config}' and collectionid= (select collectionid from mm_configcoll where name='${collection}'));" | psql -d mgrdb -p 5445 -U mmsuper > /tmp/config.${config}.txt
                                if [[ $f == *.xml ]]; then
                                {
                                        versionInfo2=`awk '/<\/versionInfo>/ { print }' /tmp/config.${config}.txt`
                                }
                                elif [[ $f == *.cfg ]]; then
                                {
                                        versionInfo2=`grep "^JobProfile.description" /tmp/config.${config}.txt | cut -d "=" -f2 | xxd -r -p`
                                }
                                fi

                                if [[ ! -z $versionInfo2 ]]; then
                                {
                                       info "Version Info for config version number $version in target enviroment is: \"$versionInfo2\""
                                       if [[ $versionInfo == $versionInfo2 ]]; then
                                               info "Same version \"$versionInfo\", then skipping configuration"
                                       else
                                               info "Deploying new version \"${versionInfo}\" of ${f} configuration in ${server}, collection=${collection}, config=${config}"
                                                deployConfig $server $collection $config `pwd`/${f}
                                       fi
                                }
                                else
                                {
                                       fatal "Not able to fetch version for ${config} in target enviroment"
                                       exit 1
                                }
                                fi
                        }
                        else
                        {
                                info "Config $config not found in target enviroment, hence deploying new ${f} configuration in ${server}, collection=${collection}, config=${config}"
                                deployConfig $server $collection $config `pwd`/${f}
                        }
                        fi

                        break # break loop and continue to next config file
                }
                fi
        }
        done
        [[ $found == 0 ]] &&  fatal "Configuration $config not found in topology, Please create new logical server and update topology variable"
}
done

exit 0