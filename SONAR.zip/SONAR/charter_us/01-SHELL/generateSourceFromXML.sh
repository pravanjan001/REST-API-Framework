#!/bin/bash

# Get settings
_DIR="${BASH_SOURCE%/*}"
if [[ ! -d "$_DIR" ]]; then DIR="$PWD"; fi
. "$_DIR/settings.sh"

if [ $# -lt 2 ]
then
  echo "Usage: $0 <full-path-XML-file> <full-path-output-dir>"
  exit 1
fi

if [ ! -e ${1} ]
then
  echo "${1}: not found"
  exit 1
fi

XMLFILE=${1}
SRCOUTPUTDIR=${2}

# Check whether the XML file is valid (a config one)
if ! grep -q '\<Application\>' ${XMLFILE}
then
  echo "${XMLFILE} is not a valid configuration file."
  exit 1
fi

# Create output dir if it doesn't exist
mkdir -p ${SRCOUTPUTDIR}

${BINDIR}/configxmltosrc.pl ${XMLFILE} ${SRCOUTPUTDIR}
if [ $? -ne 0 ]
then
  echo "Error processing ${XMLFILE}"
  exit 1
fi

echo "Source code generated sucessfully."
