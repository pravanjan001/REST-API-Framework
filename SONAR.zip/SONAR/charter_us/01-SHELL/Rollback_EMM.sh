#!/bin/bash


source /opt/test/shell/env_info.config

if [ -f "/opt/test/shell/version.txt" ]
then
  echo "Rollback version file is present , proceed with rollback"
  
else
  echo "Rollback version file is not present. Stopping the rollback"
  exit 1
fi

for i in $(echo $_CONFIG | sed "s/,/ /g")
do
 echo "config to be rollback $i"

#unprovisions the specified configuration from the Mediation server.
 $clipath/cli startcommand $EMM_USERNAME $EMM_PASSWORD $SERVER_IP:8080 unprovision -coll $_COLLECTION -config $i -s $_SERVER
 echo $?
 if [ $? != 0 ];
 then
  echo "Unprovision EMM Configuration Failed"
  exit 1
 else
  echo "Unprovision EMM Configuration successfull. Continue with Rollback"
 fi
 
 _VERSION=$(cat /opt/test/shell/version.txt)
 echo "Previos version is $_VERSION"

#provision the configuration with previous version.
 $clipath/cli startcommand $EMM_USERNAME $EMM_PASSWORD $SERVER_IP:8080 provision -coll $_COLLECTION -config $i -v $_VERSION -s $_SERVER
 if [ $? != 0 ];
 then
  echo "Provision EMM Configuration Failed"
  exit 1
 else
  echo "Provision EMM Configuration successfull. Continue with Deployment"
 fi
done
