
# EMM DevOps Pipeline.

This pipeline will deploy EMM configurations to target environments.
If the OLM is in scope,then sonarqube analysis can be performed on the extracted java code.
The pipeline architecture uses the Rosetta platform and relies on a DDS server that mixes the use of a gitlab-runner and Ansible to perform the full deploy while keeping your network safe.
Secure encrypt of passwords by gitlab
The task will perform the following steps:
Extract the java code from configuration(For OLM)
Source code analysis(For OLM)
Configuration imported and provisioned to the target environments through ansible.
If the above step is failing,then the configuration will be provisioned with previous version automatically as part of rollback.

## Getting Started
Edit file 02-ENV-INFO/env_info.config to add your target environment configuration details.
Commit the configuration in 03-ARTIFACTS folder .
Save and commit the changes
Generatesource and Codescan are the automatic jobs and followed by Build_deploy is manuall trigger.


### Prerequisites
Commit the configuration in 03-ARTIFACTS folder .
Select the destination servers. Make sure that you have: 
Admin rights
Memory and HDD requirements
Access to the database server
Access to the DDS servers
More changes

