# wiremock-stub-server
wiremock-stub-server
Link: https://www.swtestacademy.com/standalone-wiremock-stub-server-creation/
