## BaseTemplateRepo ##
## This repository is automaticlly created ##
## Contact to DevOps team for any permission or further assistance ##
# E/// Property#