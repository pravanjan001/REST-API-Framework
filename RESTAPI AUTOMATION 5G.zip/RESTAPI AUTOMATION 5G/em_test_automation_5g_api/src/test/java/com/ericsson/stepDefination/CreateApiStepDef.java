package com.ericsson.stepDefination;

import static com.ericsson.utility.PropertyHolder.getProperty;
import static com.ericsson.utility.PropertyHolder.setProperty;
import static com.ericsson.utility.ResponseUtils.response;

import com.ericsson.base.SerenityBase;
import com.ericsson.endpoints.Constants;
import com.ericsson.utility.PropertyHolder;
import com.ericsson.utility.Utility;

import cucumber.api.DataTable;
import cucumber.api.java.en.When;
import net.serenitybdd.rest.SerenityRest;

public class CreateApiStepDef  extends SerenityBase{
	
	 public static String updatepayload;
	
	@When("^I send the \"([^\"]*)\" request to \"([^\"]*)\" using request body \"([^\"]*)\" and token$")
	public void i_send_the_request_to_using_request_body_and_token(String method, String endpoint, String jsonBody, DataTable table)throws Throwable {
		updatepayload = Utility.readJson(jsonBody);

        updatepayload = Utility.updateRequestBody(table, updatepayload);
        
    	if(!getProperty(Constants.TOKEN).contains("Bearer"))
    		setProperty("token","Bearer " + getProperty(Constants.TOKEN));
    	
    	
    	response = Utility.doRequest(
                SerenityRest.given().body(updatepayload).
                contentType(Utility.getContentTypeFromDataTable(table)).
                headers(Utility.setValuesInMap(Utility.getMapFromDataTableUsingKey(table, "headers"))).
                pathParams(Utility.setValuesInMap(Utility.getMapFromDataTableUsingKey(table, "pathParam"))),
                method, getProperty(Constants.URL));
    	
    	
 
		
	}
	
	@When("^I send the \"([^\"]*)\" request to \"([^\"]*)\" using request body \"([^\"]*)\" and token invalid$")
	public void i_send_the_request_to_using_request_body_and_token_invalid(String method, String endpoint, String jsonBody, DataTable table)throws Throwable {
		updatepayload = Utility.readJson(jsonBody);

        updatepayload = Utility.updateRequestBody(table, updatepayload);
		
    	response = Utility.doRequest(
                SerenityRest.given().body(updatepayload).
                contentType(Utility.getContentTypeFromDataTable(table)).
                headers(Utility.setValuesInMap(Utility.getMapFromDataTableUsingKey(table, "headers"))).
                pathParams(Utility.setValuesInMap(Utility.getMapFromDataTableUsingKey(table, "pathParam"))),
                method, getProperty(Constants.URL));
	}
	

	
	
	
	
}
