
package com.ericsson.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.ericsson.base.SerenityBase;

// TODO: Auto-generated Javadoc
/**
 * The Class InitClass.
 */
public class InitClass extends SerenityBase {

	/** The app logs. */
	private static Logger APP_LOGS = null;

	/** The str state. */
	protected static ArrayList<String> strState = new ArrayList<>();

	/** The config. */
	protected static Properties CONFIG;

	/** The user config. */
	protected static Properties USER_CONFIG;

	/** The file seprator. */
	protected static String fileSeprator = System.getProperty("file.separator");

	/**
	 * Instantiates a new inits the class.
	 *
	 * @param path
	 *            the path
	 */
	public InitClass(String path) {
	}

	/**
	 * Instantiates a new inits the class.
	 */
	public InitClass() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Now.
	 *
	 * @param dateFormat
	 *            the date format
	 * @return the string
	 */
	public static String now(String dateFormat) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		return sdf.format(cal.getTime());
	}

	/**
	 * Initialize logger.
	 *
	 * @param basePath
	 *            the base path
	 * @return the logger
	 */
	public static synchronized Logger initializeLogger(String basePath) {
		String logDate = now("dd.MMMMM.yyyyhh.mm.ss");
		try {
			System.setProperty("log.dir", basePath + File.separator + File.separator + "testLogs" + File.separator
					+ "ApplicationLog_" + logDate + ".log");
			APP_LOGS = Logger.getLogger("automation");
		} catch (Exception e) {
			APP_LOGS.debug("Exception during Logger Creation " + e);
		}
		APP_LOGS.debug(" initializeLogger " + basePath + " - " + logDate);
		APP_LOGS.debug("Logger Initiated");

		return APP_LOGS;
	}

	/**
	 * Initialize external config file.
	 *
	 * @param folderPath
	 *            the folder path
	 * @return the string
	 */
	public static synchronized String initializeExternalConfigFile(String folderPath) {
		APP_LOGS.debug("config Initiated :" + folderPath);
		InputStreamReader fileConfig2 = null;
		FileInputStream fis = null;
		try {
			fis = new FileInputStream((folderPath + fileSeprator + "mobileconfig.properties"));

			fileConfig2 = new InputStreamReader(fis, "UTF-8");
			USER_CONFIG = new Properties();
			USER_CONFIG.load(fileConfig2);
			APP_LOG.info("User config loaded");
			return "Success";
		} catch (Exception e) {
			APP_LOGS.debug("config file not Initiated" + e);
			return null;
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					APP_LOGS.error("config file not Initiated" + e);
				}
			}
			if (fileConfig2 != null) {
				try {
					fileConfig2.close();
				} catch (IOException e) {
					APP_LOGS.error("config file not Initiated" + e);
				}
			}

		}

	}

	/**
	 * Load external config.
	 *
	 * @return the properties
	 */
	public static Properties loadExternalConfig() {
		try {

			if (USER_CONFIG == null) {
				initializeExternalConfigFile(projectPath);

			}

			return USER_CONFIG;
		} catch (Exception e) {
			APP_LOG.error("" + e);
			return USER_CONFIG;
		}
	}

}
