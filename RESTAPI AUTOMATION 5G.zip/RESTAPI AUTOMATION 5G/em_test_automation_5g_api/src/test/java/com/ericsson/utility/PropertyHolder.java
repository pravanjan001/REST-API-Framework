package com.ericsson.utility;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

// TODO: Auto-generated Javadoc
/**
 * The Class PropertyHolder.
 */
public class PropertyHolder {

	/** The Constant propertyMap. */
	static final Map<String, String> propertyMap = new HashMap<>();

	/**
	 * Gets the property.
	 *
	 * @param attribute
	 *            the attribute
	 * @return the property
	 */
	public static String getProperty(String attribute) {
		return propertyMap.get(attribute);
	}

	/**
	 * Gets the all property.
	 *
	 * @return the all property
	 */
	public static Set<Entry<String, String>> getAllProperty() {
		return propertyMap.entrySet();
	}

	/**
	 * Sets the property.
	 *
	 * @param attribute
	 *            the attribute
	 * @param value
	 *            the value
	 */
	public static void setProperty(String attribute, String value) {
		propertyMap.put(attribute, value);
	}

	/**
	 * Sets the properties.
	 *
	 * @param map
	 *            the map
	 */
	public static void setProperties(Map<String, String> map) {
		propertyMap.putAll(map);
	}
	  public static void removeProperty(String key) {
	        propertyMap.remove(key);
	    }
}
