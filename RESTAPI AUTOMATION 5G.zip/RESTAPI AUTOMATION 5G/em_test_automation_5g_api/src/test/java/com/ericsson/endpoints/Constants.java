package com.ericsson.endpoints;

public class Constants {

    public static final String URL = "url";

    public static final String ERROR_DESCRIPTION = "NOT FOUND";

    public static final String USER_DESCRIPTION_INCORRECT_LEARNING_ID = "Requested ID does not exist.";

    public static final String USER_DESCRIPTION_BLANK_LEARNING_ID = "Requested ID does not exist.";

    public static final String METHOD_TYPE = "methodType";

    public static final String REQUEST_JSON = "requestJson";
    public static final Boolean TRUE = true;

    public static final Boolean FALSE = false;
    
    public static final String TOKEN = "token";
    
    public static final String TABLENAME = "tablename";
    
    public static final String JSON_RESPONSE = "jsonResponse";

}
