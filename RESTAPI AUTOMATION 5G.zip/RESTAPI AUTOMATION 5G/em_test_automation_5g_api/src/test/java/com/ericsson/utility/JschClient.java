package com.ericsson.utility;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import org.junit.Assert;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class JschClient {
	public static void runSudoCommand(String user, String password, String host, String [] commands) {

		Properties config = new Properties();
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		Session session;
		try {
			session = jsch.getSession(user, host, 22);
			session.setPassword(password);
			session.setConfig(config);
			session.connect();
			System.out.println("Connected to " + host);
			for(int i=0;i<commands.length;i++) {
			executeCommand(password, commands[i], session);
			}
			session.disconnect();
			System.out.println("DONE");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void executeCommand(String password, String command, Session session)
			throws JSchException, IOException {
		Channel channel = session.openChannel("exec");
		// ((ChannelExec) channel).setCommand("sudo -S -p '' " + command);
		((ChannelExec) channel).setCommand(command);
		channel.setInputStream(null);
		OutputStream out = channel.getOutputStream();
		((ChannelExec) channel).setErrStream(System.err);
		InputStream in = channel.getInputStream();
		((ChannelExec) channel).setPty(true);
		channel.connect();
		out.write((password + "\n").getBytes());
		out.flush();
		byte[] tmp = new byte[1024];
		while (true) {
			while (in.available() > 0) {
				int i = in.read(tmp, 0, 1024);
				if (i < 0)
					break;
				System.out.print(new String(tmp, 0, i));
			}
			if (channel.isClosed()) {
				System.out.println("Exit status: " + channel.getExitStatus());
				break;
			}
		}
		channel.disconnect();
	}
	
	public static void runComm(String user, String password, String host, String command, String expectedoutput) {
		Properties config = new Properties();
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		Session session;
		try {
			session = jsch.getSession(user, host, 22);
			session.setPassword(password);
			session.setConfig(config);
			session.connect();
			System.out.println("Connected to " + host);
			String commandresponse = executeComm(password, command, session);
			commandresponse = commandresponse.replaceAll("\\n", "");
			System.out.println("commandresponse -->" + commandresponse);
			System.out.println("expectedoutput -->" + expectedoutput);
			session.disconnect();
			System.out.println("DONE");
			try {
				//Utility.compareValues(j,i);
				Utility.compareValues(expectedoutput,commandresponse);
				//Assert.assertSame(expectedoutput, commandresponse);
				//Assert.assertSame(j, i);
             }
             catch (Exception e) {
                Assert.assertTrue("" + e, false);
             }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	public static String executeComm(String password, String command, Session session)
			throws JSchException, IOException {
		System.out.println("command -->" + command);
		ChannelExec channel = (ChannelExec)session.openChannel("exec");
		channel.setCommand(command);
		StringBuilder outputBuffer = new StringBuilder();
		StringBuilder errorBuffer = new StringBuilder();

		InputStream in = channel.getInputStream();
		InputStream err = channel.getExtInputStream();
		//Channel channel = session.openChannel("exec");
		//((ChannelExec) channel).setCommand(command);
		//channel.setInputStream(null);
		//OutputStream out = channel.getOutputStream();
		//((ChannelExec) channel).setErrStream(System.err);
		//InputStream in = channel.getInputStream();
		//((ChannelExec) channel).setPty(true);
		channel.connect();
		//out.write((password + "\n").getBytes());
		//out.flush();
		byte[] tmp = new byte[1024];
		while (true) {
		    while (in.available() > 0) {
		        int i = in.read(tmp, 0, 1024);
		        if (i < 0) break;
		        outputBuffer.append(new String(tmp, 0, i));
		        //output = outputBuffer.toString();
		    }
		    while (err.available() > 0) {
		        int i = err.read(tmp, 0, 1024);
		        if (i < 0) break;
		        errorBuffer.append(new String(tmp, 0, i));
		    }
		    if (channel.isClosed()) {
		        if ((in.available() > 0) || (err.available() > 0)) continue; 
		        System.out.println("exit-status: " + channel.getExitStatus());
		        break;
		    }
		    try { 
		      Thread.sleep(1000);
		    } catch (Exception ee) {
		    }
		}
		String output = outputBuffer.toString();
		//System.out.println("output: " + output);

		channel.disconnect();
		return output;
	}
	
}
