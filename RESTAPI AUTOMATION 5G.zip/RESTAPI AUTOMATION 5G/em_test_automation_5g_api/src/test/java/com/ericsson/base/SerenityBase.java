package com.ericsson.base;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.AfterClass;

import com.ericsson.endpoints.APIEndPoints;
import com.ericsson.endpoints.Constants;
import com.ericsson.endpoints.JsonPath;
import com.ericsson.utility.InitClass;
import com.ericsson.utility.PropertyManager;
import com.ericsson.utility.ReadConfigXlsFiles;
import com.ericsson.utility.Utility;

import io.restassured.specification.RequestSpecification;

// TODO: Auto-generated Javadoc
/**
 * The Class SerenityBase.
 */
public class SerenityBase {

    /** The config properties. */
    static Properties configProperties;

    /** The request. */
    static RequestSpecification request;

    /** The project path. */
    protected static String projectPath;

    /** The platform. */
    protected static String platform;

    /** The app log. */
    protected static Logger APP_LOG = null;

    /** The configurations xls map. */
    protected static Map<String, String> configurationsXlsMap = new HashMap<>();
    protected static List<String> skipEnvList = new ArrayList<String>();
    protected static String skipEnv;

    /** The execution enviroment. */
    protected static String executionEnviroment;

    /** The global wait. */
    protected static String globalWait;

    /** The content type. */
    protected static String contentType;

    /** The delete from couchbase. */
    protected static String dbUser;
    protected static String dbPassword;
    protected static String deleteData;

    /** The queries. */
    public static Properties queries = new Properties();

    /** The generated ids. */
    public static Map<String, String> generatedIds = new HashMap<>();

    static {
        init();
        readQueryPropertiesFile();
    }

    /**
     * Initialize config.property available under resource folder
     * 
     */
    private static synchronized void init() {
        try {

            if (projectPath == null || "".equals(projectPath)) {
                projectPath = PropertyManager.getInstance()
                        .getValueForKey("ProjectPath").trim();
                if (APP_LOG == null) {
                    APP_LOG = InitClass.initializeLogger(projectPath);
                    PropertyConfigurator.configure(System
                            .getProperty("user.dir")
                            + "/src/test/resources/configFiles/propertiesFile/log4j.properties");
                }
                executionEnviroment = PropertyManager.getInstance()
                        .valueFromConfig("Execution_environment").trim();
                globalWait = PropertyManager.getInstance()
                        .valueFromConfig("GlobalWait").trim();
                deleteData = PropertyManager.getInstance()
                        .valueFromConfig("DeleteData").trim();
                dbUser = PropertyManager.getInstance().valueFromConfig("dbUser")
                        .trim();
                dbPassword = PropertyManager.getInstance()
                        .valueFromConfig("dbPassword").trim();
                skipEnv = PropertyManager.getInstance()
                        .valueFromConfig("SkipEnv").trim();
                skipEnvList = Arrays.asList(skipEnv.split(","));
            }

            if (configurationsXlsMap.isEmpty()) {
                readEnvironmentConfigurationFile();
                if (dbUser.equals("CB_Username")) {
                    dbUser = configurationsXlsMap.get("dbUser");
                    dbPassword = configurationsXlsMap.get("dbPassword");
                }
            }

            Utility.putVariablesInMap(APIEndPoints.class);
            Utility.putVariablesInMap(JsonPath.class);
            Utility.putVariablesInMap(Constants.class);
        } catch (Exception e) {

            if (APP_LOG == null) {
                APP_LOG = InitClass.initializeLogger(projectPath);
                PropertyConfigurator.configure(System.getProperty("user.dir")
                        + "/src/test/resources/configFiles/propertiesFile/log4j.properties");
                APP_LOG.error(
                        "Error during reading of config.property file, this is expected if user is "
                                + "running it from testng.xml and passing params from xml it self",
                        e);
            }
        }
    }

    public static synchronized void readEnvironmentConfigurationFile() {
        APP_LOG.debug("Reading Environment configuration file");
        ReadConfigXlsFiles objConfigXlsFiles = new ReadConfigXlsFiles();
        configurationsXlsMap = objConfigXlsFiles.readConfigurationsXls(
                projectPath, executionEnviroment.trim(), APP_LOG);
    }

    /**
     * Read query properties file.
     */
    public static synchronized void readQueryPropertiesFile() {
        InputStream stream = Thread.currentThread().getContextClassLoader()
                .getResourceAsStream(
                        "configFiles/propertiesFile/queries.properties");
        try {
            queries.load(stream);
        } catch (IOException e) {
            APP_LOG.error("Error on reading queries config file");
        }
    }

    /**
     * Teardown.
     */
    @AfterClass
    public static void teardown() {
        if (!generatedIds.isEmpty()) {
            Utility.deleteDataFromCouchbase();
        }
    }

}
