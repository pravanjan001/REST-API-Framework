package com.ericsson.builders;

import static com.ericsson.utility.ResponseUtils.response;

import org.junit.Assert;

import com.ericsson.base.SerenityBase;
import com.ericsson.utility.Utility;

import net.minidev.json.JSONObject;
import net.thucydides.core.annotations.Step;

// TODO: Auto-generated Javadoc
/**
 * The Class CommonSteps.
 */
public class CommonSteps extends SerenityBase {

	/** The escrow ID. */
	String url, base_url, escrowID;

	/** The Authorization token. */
	String AuthorizationToken;

	/** The json object. */
	JSONObject jsonObject;

	/** The user name. */
	public static String user_name = Utility.getRandomUsername();

	/**
	 * Verify status for create account.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Step
	public void verify_status_for_create_account() throws Exception {
		Assert.assertEquals("201", response.statusCode());
		APP_LOG.info("Response is - " + response.statusCode());
	}

	/**
	 * Creates the end point.
	 *
	 * @param base_url
	 *            the base url
	 * @param ApiEndpoint
	 *            the api endpoint
	 * @return the string
	 */
	@Step
	public String createEndPoint(String base_url, String ApiEndpoint) {
		System.out.println(base_url + ApiEndpoint);
		return base_url + ApiEndpoint;
	}
	
	

}
