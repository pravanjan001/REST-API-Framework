package com.ericsson.stepDefination;

import static com.ericsson.utility.PropertyHolder.getProperty;
import static com.ericsson.utility.PropertyHolder.setProperty;
import static com.ericsson.utility.ResponseUtils.couchbaseResponse;
import static com.ericsson.utility.ResponseUtils.requestPayload;
import static com.ericsson.utility.ResponseUtils.response;
import static io.restassured.config.EncoderConfig.encoderConfig;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jetty.client.HttpClient;
import org.eclipse.jetty.client.api.ContentResponse;
import org.eclipse.jetty.client.api.Request;
import org.eclipse.jetty.client.util.StringContentProvider;
import org.eclipse.jetty.http.HttpHeader;
import org.eclipse.jetty.http.HttpVersion;
import org.eclipse.jetty.http2.client.HTTP2Client;
import org.eclipse.jetty.http2.client.http.HttpClientTransportOverHTTP2;
import org.eclipse.jetty.util.ssl.SslContextFactory;
import org.json.JSONArray;
import org.junit.Assert;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import java.io.File;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchema;
import com.github.fge.jsonschema.main.JsonSchemaFactory;

import com.ericsson.base.SerenityBase;
import com.ericsson.endpoints.Constants;
import com.ericsson.utility.JschClient;
import com.ericsson.utility.PropertyHolder;
import com.ericsson.utility.ResponseUtils;
import com.ericsson.utility.Utility;
import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import com.github.fge.jsonschema.main.JsonValidator;
import com.jayway.jsonpath.JsonPath;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.serenitybdd.core.exceptions.UnrecognisedException;
import net.serenitybdd.rest.SerenityRest;

public class CommonStepDef extends SerenityBase {

    public static String updatepayload;
 //   public static String message;

    public static HashMap<String, Response> responseMap = new HashMap<String, Response>();
    public static HashMap<String, JSONArray> couchbaseResponseMap = new HashMap<String, JSONArray>();
    

    @And("^I have the response of \"([^\"]*)\" from the couchbase in the \"([^\"]*)\" with empty data$")
    public void i_have_the_couchbase_response_of_query_from_something_empty_data(
                   String query, String cluster, DataTable table)
                   throws Throwable {
        try {
            query = Utility.getQuery(query);

            for (int i = 1; i < table.raw().size(); i++) {

                String values = getProperty(table.raw().get(i).get(1)) == null
                        ? table.raw().get(i).get(1)
                        : getProperty(table.raw().get(i).get(1));
                query = query.replace(table.raw().get(i).get(0), values);
            }
        } catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }

        couchbaseResponse = Utility.getResultArrayFromCouchbaseResponse(
                Utility.getDbData(cluster, query));
        Assert.assertTrue("No data in couchbase query",
                couchbaseResponse.length() == 0);

    }

    @When("^I send the \"([^\"]*)\" request to \"([^\"]*)\" using path query parameters and request body as \"([^\"]*)\"$")
    public void i_send_the_something_request_to_something_using_path_query_parameters_and_request_body_as_something(
                   String methodType, String endpoint, String jsonBody,
                   DataTable table) {

        response = Utility.doRequest(SerenityRest.given()
                .urlEncodingEnabled(Constants.FALSE)
                .queryParams(Utility.setValuesInMap(Utility
                        .getMapFromDataTableUsingKey(table, "queryParam")))
                .pathParams(Utility.setValuesInMap(Utility
                        .getMapFromDataTableUsingKey(table, "pathParam")))
                .config(RestAssured.config().encoderConfig(

                        encoderConfig()
                                .appendDefaultContentCharsetToContentTypeIfUndefined(
                                        Constants.FALSE)))

                .headers(Utility.setValuesInMap(
                        Utility.getMapFromDataTableUsingKey(table, "headers")))
                .contentType((Utility.getContentTypeFromDataTable(table)))
                .body(Utility.updateRequestBody(table,
                        Utility.readJson(jsonBody))),
                methodType, getProperty(Constants.URL));

    }

    @Then("^I should update the following parameters in request payload$")
    public void i_should_see_the_following_parameters_in_request_payload(
            DataTable table) throws Throwable {
        try {
            for (int i = 1; i < table.raw().size(); i++) {
                Utility.createRandomRandomUUID(table.raw().get(i).get(0),
                        table.raw().get(i).get(1));
            }
        } catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }
    }


    @Then("^I should update the existing parameters in request payload$")
    public void i_should_see_the_existing_parameters_in_request_payload(
            DataTable table) throws Throwable {
        try {
            for (int i = 1; i < table.raw().size(); i++) {
                String existingProperty = getProperty(
                        table.raw().get(i).get(0));
                String updatedProperty = existingProperty.replace(
                        table.raw().get(i).get(1), table.raw().get(i).get(2));
                setProperty(table.raw().get(i).get(3), updatedProperty);
            }
        } catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }
    }


    @And("^I should see the response headers as$")
    public void i_should_see_the_response_headers_as(DataTable table)
            throws Throwable {
        for (int i = 1; i < table.raw().size(); i++) {
            response.then().header(table.raw().get(i).get(0),
                    table.raw().get(i).get(1));
        }
    }

    @When("^I send the \"([^\"]*)\" request to \"([^\"]*)\" using request body \"([^\"]*)\"$")
    public void i_send_the_something_request_to_something_using_request_body_something(
                   String method, String endpoint, String jsonBody,
                   DataTable table) throws Throwable {

    	updatepayload = Utility.readJson(jsonBody);
    	
    	response = Utility.doRequest(
                SerenityRest.given().body(updatepayload).
                contentType(Utility.getContentTypeFromDataTable(table)).
                headers(Utility.setValuesInMap(Utility.getMapFromDataTableUsingKey(table, "headers"))).
                pathParams(Utility.setValuesInMap(Utility.getMapFromDataTableUsingKey(table, "pathParam"))),
                method, getProperty(Constants.URL));
    }
    
    @When("^I send the http2 POST request using request body \"([^\"]*)\" I get response code as (\\d+)$")
    public void i_send_the_http_POST_request_using_request_body_I_get_response_code_as(
                   String jsonBody, String code,
                   DataTable table) throws Throwable {
    	
    	updatepayload = Utility.readJson(jsonBody);
    	System.out.println("Request Json======>"+updatepayload);
    
    	HTTP2Client http2Client = new HTTP2Client();
    	@SuppressWarnings("deprecation")
		SslContextFactory sslContextFactory = new SslContextFactory();
    	//http2Client.setConnectTimeout(50000);
    	//http2Client.setIdleTimeout(50000);
    	HttpClient httpClient = new HttpClient(new HttpClientTransportOverHTTP2(http2Client), sslContextFactory);
    	httpClient.start();
    	System.out.println("httpClient Started");
    	
    	
    	//ContentResponse response = httpClient.POST("https://127.0.0.1:12345/nchf-convergedcharging/v2/chargingdata/12312312/update").header(HttpHeader.CONTENT_TYPE, "application/json").content(new StringContentProvider("application/json", updatepayload, StandardCharsets.UTF_8)).send();
    	String url = getProperty(Constants.URL);
    	if(url.contains("{chargingid}")) {
    		String chargingid = Utility.getChargingIDFromDataTable(table);
        	System.out.println("chargingid" + chargingid);
        	url = url.replace("{chargingid}", chargingid);
    	}
    	System.out.println("url is====>" + url);
    	
    	Request request =  httpClient.POST(url);
        request.header(HttpHeader.CONTENT_TYPE, "application/json");
        //request.param(name, value)
        request.version(HttpVersion.HTTP_2);
        request.content(new StringContentProvider(updatepayload));
        System.out.println("*********"+request.toString());
        try {
        	ContentResponse response = request.send();
        	System.out.println("Status Code --->" + response.getStatus());
        	Assert.assertEquals(Integer.parseInt(code), response.getStatus());
        	
        	System.out.println("response----------->"+response.getContentAsString());
        	Assert.assertNotNull(response.getContentAsString());
        	//JSONAssert.assertEquals(Utility.readResponseJsonSchema("Response"), response.getContentAsString(), JSONCompareMode.LENIENT);
        	//Assert.assertEquals(response.getContentAsString().replaceAll("\\s",""),Utility.readResponseJsonSchema("Response").replaceAll("\\s",""));
        
            //ObjectMapper mapper=new ObjectMapper();
            
            //JsonNode schemaNode=mapper.readTree(Utility.readResponseJsonSchema("Response"));
            //JsonNode dataNode=mapper.readTree(response.getContentAsString());
            //System.out.println("schemaNode----------->"+schemaNode);
            //System.out.println("dataNode----------->"+dataNode);
            //assertEquals(schemaNode, dataNode);
           
        }
        catch (Exception ex) {
        	ex.printStackTrace();
            }
        httpClient.stop();
    }
    

    @When("^I send the \"([^\"]*)\" request using request body \"([^\"]*)\"$")
    public void i_send_the_something_request_using_request_body_something(
                   String method, String jsonBody,
                   DataTable table) throws Throwable {

        updatepayload = Utility.readJson(jsonBody);

        updatepayload = Utility.updateRequestBody(table, updatepayload);
        response = Utility.doRequest(SerenityRest.given().body(updatepayload)
                .contentType(Utility.getContentTypeFromDataTable(table) == null
                        ? "application/json"
                        : Utility.getContentTypeFromDataTable(table)),
                method, getProperty(Constants.URL));
    }

   

    @When("^I send the post request to \"([^\"]*)\" using$")
    public void i_send_the_post_request_to_something_using(String endpoint,
            DataTable table) throws Throwable {
        Map<String, String> pathParams = Utility
                .getMapFromDataTableUsingKey(table, "pathParam");

        RequestSpecification request = SerenityRest.given()
                .pathParams(Utility.setValuesInMap(pathParams));

        response = Utility.doRequest(request, "post",
                PropertyHolder.getProperty("url"));

    }

    
    @Given("^I have the endpoint as \"([^\"]*)\"$")
    public void i_have_the_endpoint_as_something(String endpoint)
            throws Throwable {
        setProperty(Constants.URL,
                Utility.createEndPoint(
                        configurationsXlsMap.get(endpoint.split("/")[0]),
                        getProperty(endpoint.split("/")[1])));
    }
    

    @When("^I send the \"([^\"]*)\" request to LEC with payload as \"([^\"]*)\"$")
    public void i_send_the_something_request_to_lec_with_payload_as_something(
            String type, String json, DataTable table) throws Throwable {
        try {
            List<List<String>> infoInTheRaw = Arrays.asList(
                    Arrays.asList("environment key",
                            "extends.sources[0]._resourceType",
                            "productResourceType"),
                    Arrays.asList("environment key",
                            "extends.sources[0]._docType", "productDocType"),
                    Arrays.asList("environment key",
                            "extends.sources[0]._assetType",
                            "productAssetType"),
                    Arrays.asList("environment key", "extends.sources[0]._id",
                            "productId"),
                    Arrays.asList("environment key",
                            "extends.sources[0]._bssVer", "productBssVer"),
                    Arrays.asList("environment key", "extends.sources[0]._ver",
                            "productVer"),
                    Arrays.asList("key to be update", "extensions.sectionId",
                            "Random String"));
            DataTable dataTable = DataTable.create(infoInTheRaw);

            String body = Utility.updateRequestBody(dataTable,
                    Utility.readJson(json));
            ResponseUtils.requestPayload = Utility.updateRequestBody(table,
                    body);

            response = Utility.doRequest(
                    SerenityRest.given()
                            .config(RestAssured.config()
                                    .encoderConfig(encoderConfig()
                                            .appendDefaultContentCharsetToContentTypeIfUndefined(
                                                    Constants.FALSE)))
                            .contentType(
                                    Utility.getContentTypeFromDataTable(table))
                            .body(ResponseUtils.requestPayload),
                    type, getProperty(Constants.URL));
        } catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }

    }

    @Then("^I should see the response status code as \"([^\"]*)\"$")
    public void i_should_see_the_response_status_code_as_something(
            int statusCode) throws Throwable {
        ResponseUtils.assertReponseStatus(statusCode);
    }
    
	/*
	 * @Then("^I should see the http2 response status code as \"([^\"]*)\"$") public
	 * void i_should_see_the_http2_response_status_code_as(int statusCode) { //
	 * Write code here that turns the phrase above into concrete actions
	 * 
	 * ContentResponse response = null; System.out.println("Status Code --->" +
	 * HttpClient. response.getStatus()); //String res = new
	 * String(response.getContent()); }
	 */

    @Then("^I should see the following parameters in response$")
    public void i_should_see_the_following_parameters_in_response(
            DataTable table) throws Throwable {
        for (int i = 1; i < table.raw().size(); i++) {
            setProperty(table.raw().get(i).get(1).replace("JSON_PATH_", ""),
                    ResponseUtils.getDataFromResponseUsingJsonPath(
                            getProperty(table.raw().get(i).get(1))));
        }
    }
    

    @When("^I send the \"([^\"]*)\" request to \"([^\"]*)\" using$")
    public void i_send_the_something_request_to_something_using(String method,
            String endpoint, DataTable table) throws Throwable {
    	
    	if(!getProperty(Constants.TOKEN).contains("Bearer"))
    		setProperty("token","Bearer " + getProperty(Constants.TOKEN));
    	
    	response = Utility.doRequest(
                SerenityRest.given().
                contentType(Utility.getContentTypeFromDataTable(table)).
                headers(Utility.setValuesInMap(Utility.getMapFromDataTableUsingKey(table, "headers"))).
                pathParams(Utility.setValuesInMap(Utility.getMapFromDataTableUsingKey(table, "pathParam"))),
                method, getProperty(Constants.URL));
    }
    
    
    @When("^I send the \"([^\"]*)\" request to \"([^\"]*)\" using below param$")
    public void i_send_some_request_to_someurl_using_below_param(String method, String endpoint, DataTable table) throws Throwable {
    	response = Utility.doRequest(
                SerenityRest.given().pathParams(Utility.setValuesInMap(Utility
                        .getMapFromDataTableUsingKey(table, "pathParam")))
                        .header("Accept", "application/json").contentType(
                                Utility.getContentTypeFromDataTable(table)),
                method, getProperty(Constants.URL));
    }

    @And("^I should see the response as per schema \"([^\"]*)\"$")
    public void i_should_see_the_response_as_per_schema_something(
            String schemaName) throws Throwable {
        ResponseUtils.validateJsonSchema(schemaName);

    }
    
    @And("^I should see the http2 response as per schema \"([^\"]*)\"$")
    public void i_should_see_the_http2_response_as_per_schema_something(
            String schemaName) throws Throwable {
        ResponseUtils.validateJsonSchema(schemaName);

    }

    @And("^I have the response of \"([^\"]*)\"$")
    public void i_have_the_response_of_something(String strArg1)
            throws Throwable {
        responseMap.put(strArg1, response);

        APP_LOG.info(response.asString());
    }
    

    @Then("^I should see that \"([^\"]*)\" response is matching with the \"([^\"]*)\" response$")
    public void i_should_see_that_something_response_is_matching_with_the_something_response(
                   String response1, String response2) {
        JSONAssert.assertEquals(responseMap.get(response1).asString(),
                responseMap.get(response2).asString(),
                JSONCompareMode.NON_EXTENSIBLE);
    }
    
    @Then("^I should see a valid token in the response$")
    public void i_should_see_a_valid_token_in_the_response() throws Throwable {
    	Assert.assertTrue(!ResponseUtils.getDataFromResponseUsingJsonPath("message.token").equals(""));
    	 setProperty(Constants.TOKEN,ResponseUtils.getDataFromResponseUsingJsonPath("message.token"));

    }

	@When("^I send the \"([^\"]*)\" request to \"([^\"]*)\" using request body as \"([^\"]*)\"$")
    public void i_send_the_something_request_to_something_using_request_body_as_something(
                   String method, String endpoint, String jsonBody,
                   DataTable table) throws Throwable {
        try {
            requestPayload = Utility.updateRequestBody(table,
                    Utility.readJson(jsonBody));
            requestPayload = requestPayload.replace("UUID",
                    Utility.generateRandomUUID());
            response = Utility.doRequest(
                    SerenityRest.given().body(requestPayload)
                            .config(RestAssured.config()
                                    .encoderConfig(encoderConfig()
                                            .appendDefaultContentCharsetToContentTypeIfUndefined(
                                                    Constants.FALSE)))
                            .contentType(Utility
                                    .getContentTypeFromDataTable(table) == null
                                            ? "application/json"
                                            : Utility
                                                    .getContentTypeFromDataTable(
                                                            table))
                            .pathParams(Utility.setValuesInMap(
                                    Utility.getMapFromDataTableUsingKey(table,
                                            "pathParam"))),
                    method, getProperty(Constants.URL));
            setProperty("REQUEST_PAYLOAD", requestPayload);
        } catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }
    }

    @And("^I have the CouchBase response of query from \"([^\"]*)\"$")
    public void i_have_the_couchbase_response_of_query_from_something(
            String cluster, DataTable table) throws Throwable {
        try {
            String query = table.raw().get(1).get(0).toString();

            for (int i = 1; i < table.raw().get(0).size(); i++) {
                query = query.replace(table.raw().get(0).get(i),
                        getProperty(table.raw().get(1).get(i)) == null
                                ? table.raw().get(1).get(i)
                                : getProperty(table.raw().get(1).get(i)));
            }
            couchbaseResponse = Utility.getResultArrayFromCouchbaseResponse(
                    Utility.getDbData(cluster, query));
            Assert.assertFalse("No data in couchbase query",
                    couchbaseResponse.length() == 0);
        } catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }
    }
    

    @Then("^I should see following in the Couchbase response from \"([^\"]*)\"$")
    public void i_should_see_following_in_the_Couchbase_response_from_something(
            String bucket, DataTable table) throws Throwable {
        try {
            for (int i = 0; i < couchbaseResponse.length(); i++) {
                for (int j = 1; j < table.raw().size(); j++) {
                    setProperty(
                            table.raw().get(j).get(1).replace("JSON_PATH_", ""),
                            Utility.getKeyValueFromJsonUsingJsonPath(
                                    couchbaseResponse
                                            .getJSONObject(i)
                                            .getJSONObject(bucket)
                                            .toString(),
                                    getProperty(
                                            table.raw().get(j).get(1)) == null
                                                    ? table.raw().get(j).get(1)
                                                    : getProperty(table.raw()
                                                            .get(j).get(1))));
                }
            }
        } catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }
    }

    @And("^I should see Couchbase response matches with the \"([^\"]*)\" schema$")
    public void i_should_see_couchbase_response_matches_with_the_something_schema(
                   String AssetEvaluationReady) throws Throwable {
        try {
            for (int i = 0; i < couchbaseResponse.length(); i++) {
                Utility.validateJsonSchema(couchbaseResponse.getJSONObject(i)
                        .getJSONObject("kafka-test")
                        .getJSONObject("eventPayload"), AssetEvaluationReady);
            }
        } catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }
    }

    @And("^I should not see any data from the CouchBase response of query from \"([^\"]*)\"$")
    public void i_should_not_see_any_data_from_the_couchbase_response_of_query_from_something(
                   String cluster, DataTable table) throws Throwable {
        try {
            String query = table.raw().get(1).get(0).toString();

            for (int i = 1; i < table.raw().get(0).size(); i++) {
                query = query.replace(table.raw().get(0).get(i),
                        getProperty(table.raw().get(1).get(i)) == null
                                ? table.raw().get(1).get(i)
                                : getProperty(table.raw().get(1).get(i)));
            }

            couchbaseResponse = Utility.getResultArrayFromCouchbaseResponse(
                    Utility.getDbData(cluster, query));
            Assert.assertTrue("No data in couchbase query",
                    couchbaseResponse.length() == 0);
        } catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }
    }

    

    @And("^I send the \"([^\"]*)\" request with payload as \"([^\"]*)\"$")
    public void i_send_the_something_request_with_payload_as_something(
            String type, String json, DataTable table) throws Throwable {
        response = Utility.doRequest(
                SerenityRest.given()
                        .config(RestAssured.config()
                                .encoderConfig(encoderConfig()
                                        .appendDefaultContentCharsetToContentTypeIfUndefined(
                                                Constants.FALSE)))
                        .contentType(Utility.getContentTypeFromDataTable(table))
                        .pathParams(Utility.setValuesInMap(
                                Utility.getMapFromDataTableUsingKey(table,
                                        "pathParam")))
                        .body(Utility.updateRequestBody(table,
                                Utility.readJson(json))),
                type, getProperty(Constants.URL));
    }

    @And("^I set the following values$")
    public void i_set_the_following_values(DataTable table) throws Throwable {
        for (int i = 1; i < table.raw().size(); i++) {
            setProperty(table.raw().get(i).get(0),
                    getProperty(table.raw().get(i).get(1)) == null
                            ? table.raw().get(i).get(1)
                            : getProperty(table.raw().get(i).get(1)));
        }
    }

    @And("^I should see the size \"([^\"]*)\" in response as expected in \"([^\"]*)\" couchbase with value \"([^\"]*)\"$")
    public void
           i_should_see_the_size_something_in_response_as_expected_in_something_couchbase_with_value_something(
                   int size, String microService, String key) {
        try {
            Assert.assertTrue(
                    "The size "
                            + couchbaseResponse.getJSONObject(0)
                                    .getJSONObject(microService)
                                    .getJSONArray(key).length()
                            + " of the " + key
                            + "in couchbase does not match with the " + size
                            + " of " + key + " from the response ",
                    couchbaseResponse.getJSONObject(0)
                            .getJSONObject(microService).getJSONArray(key)
                            .length() == size);
        } catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }

    }

    

    @And("^I should see the wait for \"([^\"]*)\" milliseconds$")
    public void i_should_see_the_wait_for_something_milliseconds(int time)
            throws Throwable {
        Thread.sleep(time);
        APP_LOG.info("Time >>>" + time);

    }

   
    @And("^I should see the following values in the response using json path as$")
    public void
           I_should_see_the_following_values_in_the_response_using_json_path_as(
                   DataTable table) throws Throwable {
        try {
            for (int i = 1; i < table.raw().size(); i++) {
                net.minidev.json.JSONArray responseValues = JsonPath
                        .parse(ResponseUtils.response.asString())
                        .read(getProperty(table.raw().get(i).get(1)));
                String responseValue = responseValues.get(0).toString();
                setProperty(table.raw().get(i).get(1).replace("JSON_PATH_", ""),
                        responseValue);
            }
        } catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }
    }

    @And("^I should get the data from response header$")
    public void i_should_get_the_data_from_response_header(DataTable table)
            throws Throwable {
        for (int i = 1; i < table.raw().size(); i++) {
            setProperty(table.raw().get(i).get(1),
                    response.header(table.raw().get(i).get(1)));

        }
    }

    @Then("^I should see the following String in response$")
    public void i_should_see_the_following_string_in_response(DataTable table)
            throws Throwable {
        for (int i = 1; i < table.raw().size(); i++) {
            Assert.assertTrue(
                    response.asString().contains(table.raw().get(i).get(1)));
            APP_LOG.info(
                    table.raw().get(i).get(1) + " is present within response");
        }

    }

    @Then("^I should see the following parameters in response as$")
    public void i_should_see_the_following_parameters_in_response_as(
            DataTable table) throws Throwable {
        try {
            for (int i = 1; i < table.raw().size(); i++) {
            		Utility.compareValues(                     
                        getProperty(table.raw().get(i).get(2)) == null
                                ? table.raw().get(i).get(2)
                                : getProperty(table.raw().get(i).get(2)),
                                ResponseUtils.getDataFromResponseUsingJsonPath(
                                        getProperty(table.raw().get(i).get(1)) == null
                                                ? table.raw().get(i).get(1)
                                                : getProperty(
                                                        table.raw().get(i).get(1))));
            }
        } catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }
    }
    
    
    @Then("^I should see a valid message in the response as$")
    public void i_should_see_a_valid_message_in_the_response_as(DataTable table) throws Throwable {
    	try 
    	{
            for (int i = 0; i < table.raw().size(); i++) {
            	if(!table.raw().get(i).get(2).equals("[]") || !table.raw().get(i).get(2).equals("")) {   		
            		String message[] = table.raw().get(i).get(2).split("\\+");
            		for (int j = 0; j < message.length; j++) {	
            			Assert.assertTrue(ResponseUtils.getDataFromResponseUsingJsonPath(table.raw().get(i).get(1)).contains(message[j]));
            		}
            	}	
            }     
        }
    	catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }
    }
    
    @Then("^I should see an empty message in the response$")
    public void i_should_see_an_empty_message_in_the_response(DataTable table) throws Throwable {
    	try {
            for (int i = 1; i < table.raw().size(); i++) {
            	String message = table.raw().get(i).get(0);;
    	
            	if(message.equals("message.token"))
            			Assert.assertTrue(ResponseUtils.getDataFromResponseUsingJsonPath("message.token").equals(""));
            	else if(message.equals("data.message"))
            			Assert.assertTrue(ResponseUtils.getDataFromResponseUsingJsonPath("data.message").equals("[]"));
            	}
            } 
            catch (Exception e) {
                Assert.assertTrue("" + e, false);
            }
    }
    
    @Then("^I have the below query response from database$")
    public void i_have_the_below_query_response_from_database(DataTable table) throws Throwable {
    	 try {
             for (int i = 1; i < table.raw().size(); i++) {
            	 String value = table.raw().get(i).get(1);
            	 if(value.contains("as"))
            	 {
            		 String[] val = value.split("\\s+"); 
            		 if(val.length > 2)
            		 value = val[2];
            	 }
            		
            	 String query =
            		        "SELECT " +  table.raw().get(i).get(1) +
            		        " FROM " + table.raw().get(i).get(0) + " WHERE " + table.raw().get(i).get(2);
            	 if(query.contains("<token>")){
            		 String token = getProperty(Constants.TOKEN);
            		 query= query.replace("<token>",token);
            	 }
            	 String expectedoutput = table.raw().get(i).get(3);
            	 String queryresponse = Utility.getDataFromDB(query, value);
            	 try {
            		 Utility.compareValues(expectedoutput,queryresponse);
                  }
                  catch (Exception e) {
                      Assert.assertTrue("" + e, false);
                  }
             }
         } catch (Exception e) {
             Assert.assertTrue("" + e, false);
         }
    	 
    }
    
    
    @Then("^I should see below details in the table$")
    public void i_should_see_below_details_in_the_table(DataTable table) throws Throwable {
    	String query ="";
    	 try {
             for (int i = 1; i < table.raw().size(); i++) {
            	 String tablename = table.raw().get(i).get(0);
            	 String whereclause  = table.raw().get(i).get(1);
            	 if(whereclause.equals(""))
            		  query = "SELECT * FROM " + tablename;
            	 else
            	     query = "SELECT * FROM " + tablename + " WHERE " + whereclause;
            	 
            	 if(query.contains("<token>")){
            		 String token = getProperty(Constants.TOKEN);
            		 query= query.replace("<token>",token);
            	 }
            	 Utility.getTableEntries(query,tablename);
             }
         } catch (Exception e) {
             Assert.assertTrue("" + e, false);
         }
    }
    
    
    @Then("^I should delete below entries from table$")
    public void i_should_delete_below_entries_from_table(DataTable table) throws Throwable {
    	String query ="";
    	 try {
             for (int i = 1; i < table.raw().size(); i++) {
            	 String tablename = table.raw().get(i).get(0);
            	 String whereclause  = table.raw().get(i).get(1);
            	 if(whereclause.equals(""))
            		  query = "DELETE FROM " + tablename;
            	 else
            	     query = "DELETE FROM " + tablename + " WHERE " + whereclause;
            	 if(query.contains("<token>")){
            		 String token = getProperty(Constants.TOKEN);
            		 query= query.replace("<token>",token);
            	 }
            	 Utility.deleteTableEntries(query, tablename);
             }
         } catch (Exception e) {
             Assert.assertTrue("" + e, false);
         }
    }
    
    @Then("^I should insert below entries in table$")
    public void i_should_insert_below_entries_in_table(DataTable table) throws Throwable {
    	String query ="";
    	 try {
             for (int i = 1; i < table.raw().size(); i++) {
            	 String tablename = table.raw().get(i).get(0);
            	 String columns  = table.raw().get(i).get(1);
            	 String values  = table.raw().get(i).get(2);
            	 
            	 query = "INSERT INTO " + tablename + " " + columns + " VALUES " + values;
            	 
            	 Utility.insertTableEntries(query,tablename);
             }
         } catch (Exception e) {
             Assert.assertTrue("" + e, false);
         }
    }
    
    
    @Then("^I should update the table with below details$")
    public void i_should_update_the_table_with_below_details(DataTable table) throws Throwable {
        String query ="";
         try {
             for (int i = 1; i < table.raw().size(); i++) {
                 String tablename = table.raw().get(i).get(0);
                 String variabletoset = table.raw().get(i).get(1);
                 String whereclause  = table.raw().get(i).get(2);
                 if(whereclause.equals(""))
                      query = "UPDATE " + tablename + " SET " + variabletoset;
                 else
                     query = "UPDATE " + tablename + " SET " + variabletoset + " WHERE " + whereclause;
                
                 if(query.contains("<token>")){
                     String token = getProperty(Constants.TOKEN);
                     query= query.replace("<token>",token);
                 }
                 Utility.deleteTableEntries(query,tablename);
             }
         } catch (Exception e) {
             Assert.assertTrue("" + e, false);
         }
    }
    
    @Then("^Run the following ssh commands$")
    public void run_the_following_ssh_commands(DataTable table) throws IOException{
    	try {
    		String user = configurationsXlsMap.get("user");
    		String host = configurationsXlsMap.get("host");
    		String password = configurationsXlsMap.get("password");
    		//String user = "mmtest";
    		//String host = "10.184.41.55";
    		//String password = "Mediation@123";
    		String[] commands=new String[99];
    		for (int i = 1; i < table.raw().size(); i++) {
    			commands[i-1]= table.raw().get(i).get(0);
        	
    		}
    		JschClient.runSudoCommand(user, password, host, commands);
    	}catch (Exception e) {
            Assert.assertTrue("" + e, false);
        }
    }
    
    @Then("^I should see below response from FNE configurations$")
    public void i_should_see_below_response_from_FNE_configurations(DataTable table) throws Throwable {
    	try {
    		String user = configurationsXlsMap.get("user");
        	String host = configurationsXlsMap.get("host");
        	String password = configurationsXlsMap.get("password");
    		 //String user = "mmtest";
             //String host = "10.184.41.55";
             //String password = "Mediation@123";
             System.out.println("Inside FNE");
             //String[] command=new String[99];
             for (int i = 1; i < table.raw().size(); i++) {
            	 String command = table.raw().get(i).get(0);
            	 String expectedoutput = table.raw().get(i).get(1);
            	 System.out.println("Executing RunCommand");
            	 JschClient.runComm(user, password, host, command, expectedoutput);
             	}
             }
         catch (Exception e) {
             Assert.assertTrue("" + e, false);
         }
    }
    
}
