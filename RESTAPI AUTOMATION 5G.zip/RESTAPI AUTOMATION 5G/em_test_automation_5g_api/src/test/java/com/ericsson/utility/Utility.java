package com.ericsson.utility;

import static com.ericsson.utility.PropertyHolder.getProperty;
import static com.ericsson.utility.PropertyHolder.setProperty;
import static io.restassured.config.EncoderConfig.encoderConfig;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Field;
import java.net.URL;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;

import org.everit.json.schema.Schema;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.junit.Assert;

import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.ericsson.base.SerenityBase;
import com.ericsson.endpoints.Constants;

import cucumber.api.DataTable;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.serenitybdd.rest.SerenityRest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

// TODO: Auto-generated Javadoc
/**
 * The Class Utility.
 *
 * @author ank
 */
public class Utility extends SerenityBase {
	  static Set<String> nodeListGlobal = new HashSet<String>();

    /**
     * Method to alter the desired key values in the JSON and returning the JSON
     * as string.
     *
     * @param jsonName
     *            the requestJson filename
     * @param jsonValues
     *            the map of jsonValues to be updated
     * @return alteredJson as string
     */
    public static synchronized String alterJson(String jsonName,
            Map<String, String> jsonValues) {
        String jsonString = null;
        try {
            URL file = Resources.getResource(
                    "configFiles/jsonFiles/RequestJson/" + jsonName);
            jsonString = Resources.toString(file, Charsets.UTF_8);

            for (Map.Entry<String, String> keyVal : jsonValues.entrySet()) {
                jsonString = jsonString.replaceAll(keyVal.getKey(),
                        keyVal.getValue());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonString;
    }

    /**
     * Validates given response against json schema.
     *
     * @param response
     *            the response as JSONObject
     * @param jsonName
     *            the response schema fileName
     */
    public static void validateJsonSchema(JSONObject response,
            String jsonName) {
        try {
            JSONObject expectedJsonSchema = new JSONObject(
                    new JSONTokener(Resources
                            .getResource(
                                    "configFiles/jsonFiles/ResponseJsonSchema/"
                                            + jsonName + ".json")
                            .openStream()));
            Schema schema = SchemaLoader.load(expectedJsonSchema);
            schema.validate(response);
        } catch (Exception e) {
            Assert.assertFalse(
                    "Error while validating response json schema: " + e,
                    Constants.TRUE);

        }
    }

    /**
     * Gets the random username.
     *
     * @return the random username
     */
    public static String getRandomUsername() {
        String alphaNumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder userName = new StringBuilder();
        userName.append("qa-EM-");
        Random rnd = new Random();
        while (userName.length() < 18) { // length of the random string.
            int index = (int) (rnd.nextFloat() * alphaNumeric.length());
            userName.append(alphaNumeric.charAt(index));
        }

        return userName.toString();
    }

    /**
     * Read jsonfile from request json.
     *
     * @param jsonName
     *            the json name
     * @return the string
     */
    public static String readJson(String jsonName) {
        try {
            URL file = Resources.getResource(
                    "configFiles/jsonFiles/RequestJson/" + jsonName + ".json");
            String jsonString = Resources.toString(file, Charsets.UTF_8);
            return jsonString;
        } catch (Exception e) {

            APP_LOG.info("Error while altering json : " + e);
            return null;
        }
    }

    /**
     * Creates the end point by concating base_url and apiEndpoint..
     *
     * @param base_url
     *            the base url
     * @param ApiEndpoint
     *            the api endpoint
     * @return the string
     */
    public static String createEndPoint(String base_url, String ApiEndpoint) {
        APP_LOG.info(base_url + ApiEndpoint);
        return base_url + ApiEndpoint;
    }

    /**
     * Read the response from the json schema.
     *
     * @param jsonSchema
     *            the json schema
     * @return the string
     */
    public static String readResponseJsonSchema(String jsonSchema) {
        try {
            URL file = Resources
                    .getResource("configFiles/jsonFiles/ResponseJsonSchema/"
                            + jsonSchema + ".json");
            String jsonString = Resources.toString(file, Charsets.UTF_8);
            return jsonString;
        } catch (Exception e) {

            APP_LOG.info("Error while altering json : " + e);
            return null;
        }
    }

    /**
     * Put varaibles in map.
     *
     * @param clz
     *            the clz
     * @throws Exception
     *             the exception
     */
    public static void putVariablesInMap(Class clz) throws Exception {
        Field[] fields = clz.getFields();
        for (Field field : fields) {
            PropertyHolder.setProperty(field.getName(),
                    (String) field.get(field));
        }
    }

    /**
     * Gets the map from data table using key.
     *
     * @param table
     *            the table
     * @param key
     *            the key
     * @return the map from data table using key
     */
    public static Map<String, String>
           getMapFromDataTableUsingKey(DataTable table, String key) {
        Map<String, String> map = new HashMap<String, String>();
        for (int i = 0; i < table.raw().size(); i++) {
            if (table.raw().get(i).get(0).equalsIgnoreCase(key)) {
                map.put(table.raw().get(i).get(1),
                        PropertyHolder
                                .getProperty(table.raw().get(i).get(2)) == null
                                        ? table.raw().get(i).get(2)
                                        : PropertyHolder.getProperty(
                                                table.raw().get(i).get(2)));
            }
        }
        return map;
    }

    /**
     * Gets the content type from data table.
     *
     * @param table
     *            the table
     * @return the content type from data table
     */
    public static String getContentTypeFromDataTable(DataTable table) {
        String contentType = null;
        for (int i = 0; i < table.raw().size(); i++) {
            if (table.raw().get(i).get(0).equalsIgnoreCase("contenttype")) {
                contentType = table.raw().get(i).get(1);
            }
        }
        return contentType;
    }
    
    public static String getChargingIDFromDataTable(DataTable table) {
        String chargingID = null;
        for (int i = 0; i < table.raw().size(); i++) {
            if (table.raw().get(i).get(0).equalsIgnoreCase("pathParam")) {
            	if (table.raw().get(i).get(1).equalsIgnoreCase("chargingid")) {
            		chargingID = table.raw().get(i).get(2);
            	}	
            }
        }
        return chargingID;
    }

    /**
     * Compare values.
     *
     * @param expected
     *            the expected
     * @param actual
     *            the actual
     */


    /**
     * Compare values false.
     *
     * @param expected
     *            the expected
     * @param actual
     *            the actual
     */


    /**
     * Gets the db data.
     *
     * @param cluster
     *            the cluster
     * @param query
     *            the query
     * @return the db data
     */
    public static Response getDbData(String cluster, String query) {
        APP_LOG.info("===>" + query);

        String url = configurationsXlsMap
                .get(configurationsXlsMap.get(cluster));

        RestAssuredConfig rac = RestAssured.config().sslConfig(new SSLConfig()
                .allowAllHostnames().relaxedHTTPSValidation("TLSv1.2"));
        try {
            Thread.sleep(Integer.valueOf(SerenityBase.globalWait));
        } catch (NumberFormatException | InterruptedException e) {
        }
        Response authenticationResponse = SerenityRest.given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("user", SerenityBase.dbUser)
                .formParam("password", SerenityBase.dbPassword).config(rac)
                .log().all().post(url + "/uilogin");

        authenticationResponse.then().statusCode(200);

        Response queryResponse = SerenityRest.given()
                .header("CouchbaseQuery", query)
                .contentType("application/x-www-form-urlencoded")
                .cookies(authenticationResponse.cookies())
                .formParam("statement", query).config(rac).log().all()
                .post(url + "/_p/query/query/service");
        queryResponse.prettyPrint();
        queryResponse.then().statusCode(200);

        return queryResponse;
    }

    /**
     * Generate random UUID.
     *
     * @return the string
     */
    public static String generateRandomUUID() {
        String uuid = UUID.randomUUID().toString();
        APP_LOG.info("Generated UUID : " + uuid);
        return uuid;
    }

    /**
     * Read json schema.
     *
     * @param jsonName
     *            the json name
     * @return the string
     */
    public static String readJsonSchema(String jsonName) {
        try {
            URL file = Resources
                    .getResource("configFiles/jsonFiles/ResponseJsonSchema/"
                            + jsonName + ".json");
            String jsonString = Resources.toString(file, Charsets.UTF_8);
            return jsonString;
        } catch (Exception e) {

            APP_LOG.info("Error while altering json : " + e);
            return null;
        }
    }

    /**
     * Removes the key from json object.
     *
     * @param jsonObject
     *            the json object
     * @param JPath
     *            the j path
     * @return the object
     */
    public static Object RemoveKeyFromJsonObject(JSONObject jsonObject,
            String JPath) {
        JSONObject ReqObj = null;
        try {
            Object document = Configuration.defaultConfiguration()
                    .jsonProvider().parse(jsonObject.toString());
            DocumentContext UpdateJson = com.jayway.jsonpath.JsonPath
                    .parse(document)
                    .delete(PropertyHolder.getProperty(JPath) == null ? JPath
                            : PropertyHolder.getProperty(JPath));
            ReqObj = new JSONObject(UpdateJson.jsonString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ReqObj;
    }

    /**
     * Validate json schema using json object.
     *
     * @param response
     *            the response
     * @param jsonSchema
     *            the json schema
     */
    public static void validateJsonSchemaUsingJsonObject(JSONObject response,
            JSONObject jsonSchema) {
        try {
            Schema schema = SchemaLoader.load(jsonSchema);
            schema.validate(response);
        } catch (Exception e) {
            Assert.assertFalse(
                    "Error while validating response json schema: " + e,
                    Constants.TRUE);

        }
    }

    /**
     * Sets the values in map by searching for specific keywords..
     *
     * @param map
     *            the map
     * @return the map
     */
    public static Map<String, String> setValuesInMap(Map<String, String> map) {
        for (Map.Entry<String, String> entry : map.entrySet()) {
            String updatedValue = checkIfGivenStringIsSomeKeyword(
                    entry.getValue());
            APP_LOG.info("Updating value for: " + entry.getKey() + " as: "
                    + updatedValue);
            map.put(entry.getKey(), updatedValue);
        }
        return map;
    }

    /**
     * Gets the date and time in UTC.
     *
     * @return the date and time in UTC
     */
    public static String getDateAndTimeInUTC() {
        SimpleDateFormat format = new SimpleDateFormat(
                "yyyy-MM-dd'T'hh:mm:ssZ");
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        return format.format(new Date());
    }

    /**
     * Gets the date and time in UTC.
     *
     * Add one hour to Current time
     *
     * @return the date and time
     */
    private static String getOneHourAheadDateAndTimeInUTC() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        return format.format(new Date(System.currentTimeMillis() + 3600000));
    }

    /**
     * Gets the epochtime.
     *
     * @return the epochtime
     */
    public static String getepochtime() {

        long epochtime = System.currentTimeMillis() / 1000;
        int time = (int) epochtime;
        String epoch = Long.toString(time);
        return epoch;

    }

    /**
     * Gets the invalid UUID.
     *
     * @return the invalid UUID
     */
    public static String getInvalidUUID() {
        return generateRandomUUID().substring(0, 10);
    }

    /**
     * Replace value from json object.
     *
     * @param jsonObject
     *            the json object
     * @param JPath
     *            the j path
     * @param Value
     *            the value
     * @return the object
     */
    public static Object ReplaceValueFromJsonObject(JSONObject jsonObject,
            String JPath, String Value) {
        JSONObject ReqObj = null;
        try {
            Object document = Configuration.defaultConfiguration()
                    .jsonProvider().parse(jsonObject.toString());
            DocumentContext UpdateJson = com.jayway.jsonpath.JsonPath
                    .parse(document)
                    .set(PropertyHolder.getProperty(JPath), Value);
            ReqObj = new JSONObject(UpdateJson.jsonString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ReqObj;
    }

    /**
     * Update request body.
     *
     * @param table
     *            the table
     * @param jsonBody
     *            the json body
     * @return the string
     */
    public static String updateRequestBody(DataTable table, String jsonBody) {
        for (int i = 0; i < table.raw().size(); i++) {
            if (table.raw().get(i).get(0)
                    .equalsIgnoreCase("key to be update")) {
                jsonBody = Utility.updateKeyValueInJson(jsonBody,
                        table.raw().get(i).get(1), table.raw().get(i).get(2));
            } else if (table.raw().get(i).get(0)
                    .equalsIgnoreCase("key to be add")) {
                jsonBody = Utility.addKeyInJson(jsonBody,
                        table.raw().get(i).get(1), table.raw().get(i).get(2));
            } else if (table.raw().get(i).get(0)
                    .equalsIgnoreCase("key to be remove")) {
                jsonBody = Utility.removeKeyFromJson(jsonBody,
                        table.raw().get(i).get(1));
            } else if (table.raw().get(i).get(0)
                    .equalsIgnoreCase("environment key")) {
                jsonBody = Utility.updateKeyValueInJson(jsonBody,
                        table.raw().get(i).get(1),
                        configurationsXlsMap.get(table.raw().get(i).get(2)));
            }
        }
        return jsonBody;

    }

    /**
     * Update key value in json.
     *
     * @param json
     *            the json
     * @param jsonPath
     *            the json path
     * @param valueToBeUpdated
     *            the value to be updated
     * @return the string
     */
    public static String updateKeyValueInJson(String json, String jsonPath,
            String valueToBeUpdated) {
        DocumentContext updateJson = null;

        Object document = Configuration.defaultConfiguration().jsonProvider()
                .parse(json);
        valueToBeUpdated = checkIfGivenStringIsSomeKeyword(valueToBeUpdated);
        jsonPath = getProperty(jsonPath) == null ? jsonPath
                : getProperty(jsonPath);

        Object addObject = Configuration.defaultConfiguration().jsonProvider()
                .parse(valueToBeUpdated);

        updateJson = JsonPath.parse(document).set(jsonPath, addObject);

        return updateJson.jsonString();
    }

    /**
     * Check if given string is some keyword.
     *
     * @param keyword
     *            the keyword
     * @return the string
     */
    public static String checkIfGivenStringIsSomeKeyword(String keyword) {
        String newKeyword = "";
        if (keyword.startsWith("(")) {
            String key = keyword.substring(1, keyword.length() - 1);
            if (key.contains(",") || key.contains("=")) {
                if (key.contains(",") && key.contains("=")) {
                    String[] keyValuePair = key.split(",");
                    for (int i = 0; i < keyValuePair.length; i++) {
                        String[] keyValue = keyValuePair[i].split("=");
                        keyValue[1] = getKeywordValue(keyValue[1]);
                        keyValuePair[i] = keyValue[0].concat("=")
                                .concat(keyValue[0]);
                    }

                    for (int i = 0; i < keyValuePair.length; i++) {
                        newKeyword += keyValuePair[i].concat(",");
                    }
                    newKeyword = "(".concat(
                            newKeyword.substring(0, newKeyword.length() - 2))
                            .concat(")");

                }
                if (key.contains("=") && (!key.contains(","))) {
                    String[] keyValue = key.split("=");
                    keyValue[1] = getKeywordValue(keyValue[1]);
                    newKeyword = "("
                            .concat(keyValue[0].concat("=").concat(keyValue[1]))
                            .concat(")");

                }
                if ((key.contains(",") && key.contains(":"))
                        && !(key.contains("="))) {
                    String[] keyValuePair = key.split(",");
                    for (int i = 0; i < keyValuePair.length; i++) {
                        String[] keyValue = keyValuePair[i].split(":");
                        keyValue[1] = getKeywordValue(keyValue[1]);
                        keyValuePair[i] = keyValue[0].concat(":")
                                .concat(keyValue[1]);
                    }
                    for (int i = 0; i < keyValuePair.length; i++) {
                        newKeyword += keyValuePair[i].concat(",");
                    }
                    newKeyword = "(".concat(
                            newKeyword.substring(0, newKeyword.length() - 1))
                            .concat(")");

                }

            } else {
                newKeyword = "(".concat(getKeywordValue(key)).concat(")");
            }
        } else {
            newKeyword = getKeywordValue(keyword);
        }
        return newKeyword;
    }

    /**
     * Adds the key in json.
     *
     * @param json
     *            the json
     * @param jPath
     *            the j path
     * @param keyValue
     *            the key value
     * @return the string
     */
    public static String addKeyInJson(String json, String jPath,
            String keyValue) {
        DocumentContext updateJson = null;
        try {

            Object document = Configuration.defaultConfiguration()
                    .jsonProvider().parse(json);
            Object addObject = Configuration.defaultConfiguration()
                    .jsonProvider().parse(keyValue.split("-")[1]);
            updateJson = JsonPath.parse(document).put(jPath,
                    keyValue.split("-")[0], addObject);
        } catch (Exception e) {
            Assert.assertTrue(e.getMessage(), Constants.FALSE);
        }
        return updateJson.jsonString();
    }

    /**
     * Removes the key from json.
     *
     * @param json
     *            the json
     * @param JPath
     *            the j path
     * @return the string
     */
    public static String removeKeyFromJson(String json, String JPath) {
        DocumentContext updateJson = null;
        try {
            Object document = Configuration.defaultConfiguration()
                    .jsonProvider().parse(json);
            updateJson = JsonPath.parse(document).delete(
                    getProperty(JPath) == null ? JPath : getProperty(JPath));
        } catch (Exception e) {
            Assert.assertTrue(e.getMessage(), Constants.FALSE);
        }
        return updateJson.jsonString();
    }

    /**
     * Gets the result array from couchbase response.
     *
     * @param response
     *            the response
     * @return the result array from couchbase response
     */
    public static JSONArray
           getResultArrayFromCouchbaseResponse(Response response) {
        return new JSONObject(response.asString()).getJSONArray("results");

    }

    /**
     * Gets the key value from json using json path.
     *
     * @param json
     *            the json
     * @param jsonPath
     *            the json path
     * @return the key value from json using json path
     */
    public static String getKeyValueFromJsonUsingJsonPath(String json,
            String jsonPath) {
        String updateJson = null;
        try {

            Object document = Configuration.defaultConfiguration()
                    .jsonProvider().parse(json);
            updateJson = JsonPath.parse(document)
                    .read(getProperty(jsonPath) == null ? jsonPath
                            : getProperty(jsonPath))
                    .toString();

            APP_LOG.info("Got key value for " + jsonPath + " as " + updateJson);

        } catch (Exception e) {
            Assert.assertTrue(e.getMessage(), Constants.FALSE);
        }
        return updateJson;
    }

    /**
     * Gets the random string.
     *
     * @return the random string
     */
    public static String getRandomString() {
        String alphaNumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder userName = new StringBuilder();
        Random rnd = new Random();
        while (userName.length() < 26) { // length of the random string.
            int index = (int) (rnd.nextFloat() * alphaNumeric.length());
            userName.append(alphaNumeric.charAt(index));
        }

        return userName.toString();
    }

    /**
     * Gets the random number.
     *
     * @return the random number
     */
    public static String getRandomNumber() {
        Random rn = new Random();
        int number = rn.nextInt(10) + 1;
        String num = Integer.toString(number);
        return num;
    }

    /**
     * Gets the key value as int from json object.
     *
     * @param jsonObject
     *            the json object
     * @param JPath
     *            the j path
     * @return the int
     */
    public static int GetKeyValueAsIntFromJsonObject(JSONObject jsonObject,
            String JPath) {
        int ReqObj = 0;
        try {
            Object document = Configuration.defaultConfiguration()
                    .jsonProvider().parse(jsonObject.toString());
            ReqObj = com.jayway.jsonpath.JsonPath.parse(document)
                    .read(PropertyHolder.getProperty(JPath) == null ? JPath
                            : PropertyHolder.getProperty(JPath));
            // ReqObj = UpdateJson.jsonString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ReqObj;
    }

    /**
     * Gets the key value from json object.
     *
     * @param jsonObject
     *            the json object
     * @param JPath
     *            the j path
     * @return the string
     */
    public static String GetKeyValueFromJsonObject(JSONObject jsonObject,
            String JPath) {
        String ReqObj = null;
        try {
            Object document = Configuration.defaultConfiguration()
                    .jsonProvider().parse(jsonObject.toString());
            ReqObj = com.jayway.jsonpath.JsonPath.parse(document)
                    .read(PropertyHolder.getProperty(JPath) == null ? JPath
                            : PropertyHolder.getProperty(JPath))
                    .toString();
            // ReqObj = UpdateJson.jsonString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ReqObj;
    }

    /**
     * Update key value in json.
     *
     * @param json
     *            the json
     * @param jsonPath
     *            the json path
     * @param valueToBeUpdated
     *            the value to be updated
     * @return the string
     */
    public static String updateKeyValueInJson(String json, String jsonPath,
            int valueToBeUpdated) {
        DocumentContext updateJson = null;
        try {
            Object document = Configuration.defaultConfiguration()
                    .jsonProvider().parse(json);
            jsonPath = getProperty(jsonPath) == null ? jsonPath
                    : getProperty(jsonPath);
            updateJson = JsonPath.parse(document).set(jsonPath,
                    valueToBeUpdated);

        } catch (Exception e) {
            Assert.assertTrue(e.getMessage(), Constants.FALSE);
        }
        return updateJson.jsonString();
    }

    /**
     * Gets the key value as int from json using json path.
     *
     * @param json
     *            the json
     * @param jsonPath
     *            the json path
     * @return the key value as int from json using json path
     */
    public static int getKeyValueAsIntFromJsonUsingJsonPath(String json,
            String jsonPath) {
        int updateJson = 0;
        try {

            Object document = Configuration.defaultConfiguration()
                    .jsonProvider().parse(json);
            updateJson = JsonPath.parse(document)
                    .read(getProperty(jsonPath) == null ? jsonPath
                            : getProperty(jsonPath));

            APP_LOG.info("Got key value for " + jsonPath + " as " + updateJson);

        } catch (Exception e) {
            Assert.assertTrue(e.getMessage(), Constants.FALSE);
        }
        return updateJson;
    }

    /**
     * Gets the query.
     *
     * @param key
     *            the key
     * @return the query
     */
    public static String getQuery(String key) {
        return SerenityBase.queries.getProperty(key);
    }

    /**
     * Genertae random array.
     *
     * @param key
     *            the key
     * @return the string
     */
    public static String genertaeRandomArray(String[] key) {
        int key1 = (int) (Math.random() * key.length);
        String value = key[key1];
        APP_LOG.info("============>>>" + key1 + value);
        return key[key1];

    }

    /**
     * Sets the generated ids.
     *
     * @param response
     *            the new generated ids
     */
    public static void setGeneratedIds(Response response) {
        if (getProperty(Constants.URL).contains("deliveryPlan")) {
            if (getProperty(Constants.URL).contains("versions")) {
                JSONObject responseObject = new JSONObject(response.asString());
                {
                    generatedIds.put(
                            "DP_ID_" + getRandomString().substring(0, 5),
                            responseObject.getString("_id"));
                    generatedIds.put(
                            "DP_VER_" + getRandomString().substring(0, 5),
                            responseObject.getString("_ver"));
                }
            }
        }

        else if (getProperty(Constants.URL).contains("policies")) {
            if (getProperty(Constants.URL).contains("versions")) {
                JSONObject responseObject = new JSONObject(response.asString());
                generatedIds.put("LAD_ID_" + getRandomString().substring(0, 5),
                        responseObject.getString("_id"));
                generatedIds.put("LAD_VER_" + getRandomString().substring(0, 5),
                        responseObject.getString("_ver"));
            } else {
                JSONArray responseArray = new JSONArray(response.asString());
                for (int i = 0; i < responseArray.length(); i++) {
                    generatedIds.put(
                            "LAD_ID_" + getRandomString().substring(0, 5),
                            responseArray.getJSONObject(i).getString("_id"));
                    generatedIds.put(
                            "LAD_VER_" + getRandomString().substring(0, 5),
                            responseArray.getJSONObject(i).getString("_ver"));
                }
            }
        }

        else if (getProperty(Constants.URL).contains("kafka")
                && !(getProperty(Constants.URL).contains("GMS"))) {
            JSONObject responseObject = new JSONObject(
                    getProperty(Constants.REQUEST_JSON));
            generatedIds.put("KAFKA_ID_" + getRandomString().substring(0, 5),
                    responseObject.getString("_id"));
            generatedIds.put("KAFKA_VER_" + getRandomString().substring(0, 5),
                    responseObject.getString("_ver"));
        }

        else if (getProperty(Constants.URL).contains("learningExperience")) {
            if (getProperty(Constants.URL).contains("clone")) {
                JSONObject responseObject = new JSONObject(response.asString());
                generatedIds.put(
                        "LECCLONE_ID_" + getRandomString().substring(0, 5),
                        responseObject.getJSONObject("root")
                                .getJSONObject("clonedExperience")
                                .getString("_id"));
                generatedIds.put(
                        "LECCLONE_VER_" + getRandomString().substring(0, 5),
                        responseObject.getJSONObject("root")
                                .getJSONObject("clonedExperience")
                                .getString("_ver"));
            } else {
                JSONObject responseObject = new JSONObject(response.asString());
                generatedIds.put("LEC_ID_" + getRandomString().substring(0, 5),
                        responseObject.getString("_id"));
                generatedIds.put("LEC_VER_" + getRandomString().substring(0, 5),
                        responseObject.getString("_ver"));
            }
        }

        else if (getProperty(Constants.URL).contains("userDefinedResources")) {
            if (getProperty(Constants.URL).contains("versions")) {
                JSONObject responseObject = new JSONObject(response.asString());
                generatedIds.put("UDR_ID_" + getRandomString().substring(0, 5),
                        responseObject.getString("_id"));
                generatedIds.put("UDR_VER_" + getRandomString().substring(0, 5),
                        responseObject.getString("_ver"));
            } else {
                JSONObject responseObject = new JSONObject(response.asString());
                for (int i = 0; i < responseObject.length(); i++) {
                    generatedIds.put(
                            "UDR_ID_" + getRandomString().substring(0, 5),
                            responseObject.getString("_id"));
                    generatedIds.put(
                            "UDR_VER_" + getRandomString().substring(0, 5),
                            responseObject.getString("_ver"));
                }
            }
        } else if (getProperty(Constants.URL)
                .contains("extractUserDefinedResources")) {
            {
                JSONArray responseArray = new JSONArray(response.asString());
                for (int i = 0; i < responseArray.length(); i++) {
                    generatedIds.put(
                            "EUDR_ID_" + getRandomString().substring(0, 5),
                            responseArray.getJSONObject(i).getString("_id"));
                    generatedIds.put(
                            "EUDR_VER_" + getRandomString().substring(0, 5),
                            responseArray.getJSONObject(i).getString("_ver"));
                }
            }
        } else if (getProperty(Constants.URL).contains("userDeliveries")) {
            {
                JSONArray responseArray = new JSONArray(response.asString());
                for (int i = 0; i < responseArray.length(); i++) {
                    generatedIds.put(
                            "UD_ID_" + getRandomString().substring(0, 5),
                            responseArray.getJSONObject(i).getString("_id"));
                    generatedIds.put(
                            "UD_VER_" + getRandomString().substring(0, 5),
                            responseArray.getJSONObject(i).getString("_ver"));
                }
            }
        }
    }

    /**
     * Delete data from couchbase.
     */
    public static void deleteDataFromCouchbase() {
        if (deleteData.equals("true")) {
            String url = configurationsXlsMap
                    .get(configurationsXlsMap.get("apiCluster"));
            RestAssuredConfig rac = SerenityRest.config()
                    .sslConfig(new SSLConfig().allowAllHostnames()
                            .relaxedHTTPSValidation("TLSv1.2"));
            Response authenticationResponse = SerenityRest.given()
                    .contentType("application/x-www-form-urlencoded")
                    .formParam("user", SerenityBase.dbUser)
                    .formParam("password", SerenityBase.dbPassword).config(rac)
                    .log().all().post(url + "/uilogin");
            authenticationResponse.then().statusCode(200);
            Set<String> keyword = generatedIds.keySet();
            for (String key : keyword) {
                if (key.startsWith("LAD")) {
                    Response queryResponse = SerenityRest.given()
                            .contentType("application/x-www-form-urlencoded")
                            .cookies(authenticationResponse.cookies())
                            .formParam("statement",
                                    "Delete from lad where _id = '"
                                            + generatedIds.get(key) + "'")
                            .config(rac).log().all()
                            .post(url + "/_p/query/query/service");
                    APP_LOG.info(queryResponse.prettyPrint());
                }

                else if (key.startsWith("kafka")) {
                    Response queryResponse = SerenityRest.given()
                            .contentType("application/x-www-form-urlencoded")
                            .cookies(authenticationResponse.cookies())
                            .formParam("statement",
                                    "Delete from `kafka-test` where meta().id = 'LAD::"
                                            + generatedIds.get(key) + "'")
                            .config(rac).log().all()
                            .post(url + "/_p/query/query/service");
                    APP_LOG.info(queryResponse.prettyPrint());

                } else if (key.startsWith("LEC")) {

                    Response queryResponse = SerenityRest.given()
                            .contentType("application/x-www-form-urlencoded")
                            .cookies(authenticationResponse.cookies())
                            .formParam("statement",
                                    "Delete from lec where meta().id = '"
                                            + generatedIds.get(key) + "'")
                            .config(rac).log().all()
                            .post(url + "/_p/query/query/service");
                    APP_LOG.info(queryResponse.prettyPrint());

                }
            }
        }
    }

    /**
     * Do request.
     *
     * @param requestSpec
     *            the request spec
     * @param methodType
     *            the method type
     * @param url
     *            the url
     * @return the response
     */
    public static Response doRequest(RequestSpecification requestSpec,
            String methodType, String url) {
        setProperty(Constants.URL, url);
        setProperty(Constants.METHOD_TYPE, methodType);

        switch (methodType.toLowerCase()) {
        case "get":
            return requestSpec.relaxedHTTPSValidation().log().all().get(url);
        case "post":
            return requestSpec.relaxedHTTPSValidation().log().all().post(url);
        case "put":
            return requestSpec.relaxedHTTPSValidation().log().all().put(url);
        case "delete":
            return requestSpec.relaxedHTTPSValidation().log().all().delete(url);
        case "patch":
            return requestSpec.relaxedHTTPSValidation().log().all().patch(url);
        default:
            Assert.assertTrue("Invalid method type passed: " + methodType,
                    Constants.FALSE);
            return null;
        }
    }

    public static Response buildRequest(DataTable table, String methodType) {
        setProperty(Constants.METHOD_TYPE, methodType);

        return doRequest(
                SerenityRest.given()
                        .contentType(getContentTypeFromDataTable(table) == null
                                ? "application/json"
                                : getContentTypeFromDataTable(table))
                        .headers(Utility.setValuesInMap(
                                getMapFromDataTableUsingKey(table, "header")))
                        .formParams(Utility.setValuesInMap(
                                getMapFromDataTableUsingKey(table,
                                        "formParam")))
                        .pathParams(Utility.setValuesInMap(
                                getMapFromDataTableUsingKey(table,
                                        "pathParam")))
                        .queryParams(Utility.setValuesInMap(
                                getMapFromDataTableUsingKey(table,
                                        "queryParam")))
                        .config(RestAssured.config()
                                .encoderConfig(encoderConfig()
                                        .appendDefaultContentCharsetToContentTypeIfUndefined(
                                                Constants.FALSE))),
                methodType, getProperty(Constants.URL));
    }

    /**
     * Creates the random random UUID.
     *
     * @param globalVariableName
     *            the global variable name
     * @param additionalParam
     *            the additional param
     */
    public static void createRandomRandomUUID(String globalVariableName,
            String additionalParam) {
        setProperty(globalVariableName,
                additionalParam + Utility.generateRandomUUID());
    }

    /**
     * Builds the request.
     *
     * @param table
     *            the table
     * @param methodType
     *            the method type
     * @return the response
     */

    public static String getKeywordValue(String keyword) {
        if (keyword.contains("Invalid UUID")) {
            setProperty(keyword, getInvalidUUID());
        } else if (keyword.contains("Valid UUID")) {
            setProperty(keyword, generateRandomUUID());
        } else if (keyword.contains("Valid date")) {
            setProperty(keyword, getDateAndTimeInUTC());
        } else if (keyword.contains("Random String")) {
            setProperty(keyword, getRandomString());
        } else if (keyword.contains("Random Number")) {
            setProperty(keyword, getRandomNumber());
        } else if (keyword.contains("Array")) {
            setProperty(keyword, new JSONArray().toString());
        } else if (keyword.contains("Future Time")) {
            setProperty(keyword, getOneHourAheadDateAndTimeInUTC());
        }

        return getProperty(keyword) == null
                ? (configurationsXlsMap.get(keyword) == null ? keyword
                        : configurationsXlsMap.get(keyword))
                : getProperty(keyword);

    }

    /**
     * Compare values.
     *
     * @param expected
     *            the expected
     * @param actual
     *            the actual
     */
 
    public static void setNodeList(Response responseParam, String type) {
        JSONObject respObj = new JSONObject(responseParam.asString());
        if (type.equalsIgnoreCase("node"))
            setNodeListInList(respObj);
        if (type.equalsIgnoreCase("graph")) {
            JSONObject newNodeJSONObj = respObj.getJSONObject("newNodes");
            setNodeListInList(newNodeJSONObj);
            JSONObject reusedNodeJSONObj = respObj.getJSONObject("reusedNodes");
            setNodeListInList(reusedNodeJSONObj);
        }
    }
    
    public static void setNodeListInList(JSONObject nodeJSONObj) {
        Set<String> nodeSet = nodeJSONObj.keySet();
        for (String key : nodeSet) {
            Utility.setNodeList(
                    nodeJSONObj.getJSONObject(key).getString("_id"));
        }
    }
    public static void setNodeList(String node) {
        nodeListGlobal.add(node);
    }

    public static void compareValues(String expected, String actual) {
        Assert.assertTrue( "Expected value: " + expected
                + " is equal to Actual value: " + actual,expected.equals(actual));
    }
    
    public static void compareValues(Integer expected, Integer actual) {
        Assert.assertTrue( "Expected value: " + expected
                + " is equal to Actual value: " + actual,expected.equals(actual));
    }
    

	public static String getDataFromDB(String query, String value) {
		String qresponse = "";
		Properties props = new Properties();
	  	PostgreSQLJDBC dbcon = new PostgreSQLJDBC();
	  	final String url = configurationsXlsMap.get("dbURL");
	  	props.setProperty("user",configurationsXlsMap.get("dbUser"));
		props.setProperty("password",configurationsXlsMap.get("dbPassword"));
		props.setProperty("ssl","false");
    	qresponse = dbcon.checkvaluefromTable(url, props, query, value);
    	//System.out.println("qresponse : "+qresponse);
    	return qresponse;
	}
	
	public static void getTableEntries(String query,String tablename) {
		Properties props = new Properties();
		final String url = configurationsXlsMap.get("dbURL");
		props.setProperty("user",configurationsXlsMap.get("dbUser"));
		props.setProperty("password",configurationsXlsMap.get("dbPassword"));
		props.setProperty("ssl","false");
	  	PostgreSQLJDBC dbcon = new PostgreSQLJDBC();
    	dbcon.connectforTableEntries(url,props,query,tablename);
	}
	
	public static void deleteTableEntries(String query,String tablename) {
		Properties props = new Properties();
		final String url = configurationsXlsMap.get("dbURL");
		props.setProperty("user",configurationsXlsMap.get("dbUser"));
		props.setProperty("password",configurationsXlsMap.get("dbPassword"));
		props.setProperty("ssl","false");
	  	PostgreSQLJDBC dbcon = new PostgreSQLJDBC();
    	dbcon.deletefromTable(url,props,query,tablename);
	}
	
	public static void insertTableEntries(String query,String tablename) {
		Properties props = new Properties();
		final String url = configurationsXlsMap.get("dbURL");
		props.setProperty("user",configurationsXlsMap.get("dbUser"));
		props.setProperty("password",configurationsXlsMap.get("dbPassword"));
		props.setProperty("ssl","false");
	  	PostgreSQLJDBC dbcon = new PostgreSQLJDBC();
    	dbcon.insertintoTable(url,props,query,tablename);
	}
}
