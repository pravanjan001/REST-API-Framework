package com.ericsson.endpoints;

public class APIEndPoints {

    public static final String ENDPOINT_CONVERGED_CHARGING_I = "/nchf-convergedcharging/v2/chargingdata";
    public static final String ENDPOINT_CONVERGED_CHARGING_U = "/nchf-convergedcharging/v2/chargingdata/{chargingid}/update";
    public static final String ENDPOINT_CONVERGED_CHARGING_R = "/nchf-convergedcharging/v2/chargingdata/{chargingid}/release";
    
    
}