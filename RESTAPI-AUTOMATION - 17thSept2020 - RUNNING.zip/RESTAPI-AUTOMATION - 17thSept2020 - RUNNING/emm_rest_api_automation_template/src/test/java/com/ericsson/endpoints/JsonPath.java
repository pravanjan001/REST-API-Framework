package com.ericsson.endpoints;

public class JsonPath {

    public static final String JSON_PATH_CODE = "data.code";

}
