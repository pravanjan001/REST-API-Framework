package com.ericsson.runnerFile;

import com.ericsson.base.SerenityBase;
import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)

@CucumberOptions(strict = false, features = "src/test/resources/features", glue = {
    "com.ericsson.stepDefination" }, tags = { "@demo" }, monochrome = true, plugin = {
        "json:target/cucumber-json-report.json", "html:target/cucumber-html-report",
        "junit:target/cucumber.xml" })

public class RunnerCukes extends SerenityBase {
			
}