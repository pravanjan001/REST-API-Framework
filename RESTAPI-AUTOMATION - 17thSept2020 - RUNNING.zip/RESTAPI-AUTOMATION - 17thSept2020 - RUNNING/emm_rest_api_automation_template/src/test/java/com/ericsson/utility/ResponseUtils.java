package com.ericsson.utility;

import org.json.JSONArray;

import com.ericsson.endpoints.Constants;

import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;

public class ResponseUtils {
	public static Response response;
	public static JSONArray couchbaseResponse;
	public static String requestPayload;

	public static String getDataFromResponseUsingJsonPath(String jsonPath) {
		return response.then().extract().jsonPath().getString(jsonPath);
	}

	public static void assertReponseStatus(int expectedStatusCode) {
		response.prettyPrint();
		response.then().statusCode(expectedStatusCode);
		if (PropertyHolder.getProperty(Constants.METHOD_TYPE).equalsIgnoreCase("post")
				&& (response.getStatusCode() == 200 || response.getStatusCode() == 201)) {
			Utility.setGeneratedIds(response);
		}

	}

	/**
	 * Here just pass the JSON schema from your step definition It will validate the
	 * JSON Schema With The Response
	 */
	public static void validateJsonSchema(String schema) {
		response.prettyPrint();
		response.then().assertThat()
				.body(JsonSchemaValidator.matchesJsonSchema(Utility.readResponseJsonSchema(schema)));

	}

}
