package com.ericsson.endpoints;

public class APIEndPoints {

    public static final String ENDPOINT_READ_SUBSCRIBER = "/v1-0/subscriber/accountnumber/{accountnumber}/lineid/{lineid}/mdn/{mdn}/startdate/{startdate}";
    public static final String ENDPOINT_READ_SUBSCRIBER_W = "/v1-0/subscriber/accountnumber/{accountnumber}/lineid/{lineid}/{mdn}/startdate/{startdate}";
    public static final String ENDPOINT_JWT_TOKEN = "/auth/login/";
    
    public static final String ENDPOINT_UPDATE_SUBSCRIBER = "/v1-0/subscriber/update-subscriber/";
    public static final String ENDPOINT_UPDATE_SUBSCRIBER_W = "/v1-0//update-subscriber/";
    public static final String ENDPOINT_CREATE_SUBSCRIBER = "/v1-0/subscriber/create-subscriber/";
    public static final String ENDPOINT_CREATE_SUBSCRIBER_W = "/v1-0/create-subscriber/";
    public static final String ENDPOINT_CHANGE_MDN = "/v1-0/subscriber/change-mdn/";
    public static final String ENDPOINT_CHANGE_MDN_W = "/v1-0/subscriber/change/";
}
