package com.ericsson.utility;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class JschClient {
	public static void runSudoCommand(String user, String password, String host, String [] commands) {

		Properties config = new Properties();
		config.put("StrictHostKeyChecking", "no");
		JSch jsch = new JSch();
		Session session;
		try {
			session = jsch.getSession(user, host, 22);
			session.setPassword(password);
			session.setConfig(config);
			session.connect();
			System.out.println("Connected to " + host);
			for(int i=0;i<commands.length;i++) {
			executeCommand(password, commands[i], session);
			}
			session.disconnect();
			System.out.println("DONE");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void executeCommand(String password, String command, Session session)
			throws JSchException, IOException {
		Channel channel = session.openChannel("exec");
		// ((ChannelExec) channel).setCommand("sudo -S -p '' " + command);
		((ChannelExec) channel).setCommand(command);
		channel.setInputStream(null);
		OutputStream out = channel.getOutputStream();
		((ChannelExec) channel).setErrStream(System.err);
		InputStream in = channel.getInputStream();
		((ChannelExec) channel).setPty(true);
		channel.connect();
		out.write((password + "\n").getBytes());
		out.flush();
		byte[] tmp = new byte[1024];
		while (true) {
			while (in.available() > 0) {
				int i = in.read(tmp, 0, 1024);
				if (i < 0)
					break;
				System.out.print(new String(tmp, 0, i));
			}
			if (channel.isClosed()) {
				System.out.println("Exit status: " + channel.getExitStatus());
				break;
			}
		}
		channel.disconnect();
	}
}
