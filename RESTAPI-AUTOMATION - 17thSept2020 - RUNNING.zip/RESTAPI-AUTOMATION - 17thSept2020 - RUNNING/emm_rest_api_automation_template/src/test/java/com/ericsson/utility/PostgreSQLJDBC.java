package com.ericsson.utility;

import static com.ericsson.utility.PropertyHolder.getProperty;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import com.ericsson.endpoints.Constants;

public class PostgreSQLJDBC {

// Declaration of the variables
    
  //  private final String url = "jdbc:postgresql://47.234.31.10:5434/fm_db_charter";
 // private final String url = configurationsXlsMap.get("dbURL");
  //  private final String user = "mmsuper";
  //  private final String password = "thule";
    public static String fname = null;

    //Properties props = new Properties();
    
    
    public String checkvaluefromTable(String url, Properties props, String query, String value) {
        Connection conn = null;
        String fname = "";
        try {
        		//props.setProperty("user","mmsuper");
        		//props.setProperty("password","thule");
        		//props.setProperty("ssl","false");
            	conn = DriverManager.getConnection(url, props);
            	conn.setAutoCommit(false);
            	System.out.println("Connected to the PostgreSQL server successfully.");
            	if (conn != null) {

                    PreparedStatement pst = conn.prepareStatement(query);
                    ResultSet rs = pst.executeQuery();
                        while (rs.next()) {
                        	
                            fname = rs.getString(1);
                            System.out.println("The value from the table is : "+fname);
                       }
                } 
        	}
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return fname;
    }
    
    public void connectforTableEntries(String url, Properties props, String query, String tablename) {
        Connection conn = null;
        try {
        		//props.setProperty("user","mmsuper");
        		//props.setProperty("password","thule");
        		//props.setProperty("ssl","false");
            	conn = DriverManager.getConnection(url, props);
            	conn.setAutoCommit(false);
            	System.out.println("==================================================Connected to the PostgreSQL server successfully=====================================================");
            	if (conn != null) {

                    PreparedStatement pst = conn.prepareStatement(query);
                    ResultSet rs = pst.executeQuery();
					if(tablename.contentEquals("subscriber"))
                    {
						System.out.println("SUBSCRIBER TABLE");
                    	System.out.println("account_id" + "\t" + "line_id" +
                                "\t" + "lineseq_start_date" + "\t\t" + "lineseq_end_date" +
                                "\t\t" + "bill_cycle_day" + "\t" + "mno_mdn" +
    							"\t" + "cbrs_imsi" + "\t" + "mno_rate_plan_code" +
    							"\t" + "is5g" + "\t" + "data_limit_lte" +
    							"\t" + "data_limit_lte_units" + "\t" + "data_limit_mhs" +
    							"\t" + "data_limit_mhs_units" + "\t" + "data_limit_5g" +
    							"\t" + "data_limit_5g_units");
                        while (rs.next()) {
                        	
                        	System.out.println(rs.getString("account_id") + "\t" + rs.getString("line_id") +
                                    "\t" + rs.getString("lineseq_start_date") + "\t" + rs.getString("lineseq_end_date") +
                                    "\t" + rs.getString("bill_cycle_day") + "\t" + rs.getString("mno_mdn") +
        							"\t" + rs.getString("cbrs_imsi") + "\t" + rs.getString("mno_rate_plan_code") +
        							"\t" + rs.getString("is5g") + "\t" + rs.getString("data_limit_lte") +
        							"\t" + rs.getString("data_limit_lte_units") + "\t" + rs.getString("data_limit_mhs") +
        							"\t" + rs.getString("data_limit_mhs_units") + "\t" + rs.getString("data_limit_5g") +
        							"\t" + rs.getString("data_limit_5g_units"));
                        	}
                    } 
					else if(tablename.contentEquals("subscriber_data_usage_lte"))
                       {
						System.out.println("SUBSCRIBER USAGE LTE TABLE");
                    	   System.out.println("account_id" + "\t" + "line_id" +
                                "\t" + "lineseq_start_date" + "\t\t" + "bc_start_date" +
                                "\t\t" + "accumulated_usage_kb" + "\t" + "mno_mdn" +
    							"\t" + "cbrs_imsi" + "\t" + "threshold_50_reached" +
    							"\t" + "threshold_80_reached" + "\t" + "threshold_90_reached" +
    							"\t" + "threshold_100_reached" + "\t" + "threshold_50_date_notified" +
    							"\t" + "threshold_80_date_notified" + "\t" + "threshold_90_date_notified" +
    							"\t" + "threshold_100_date_notified" + "\t" + "data_limit_kb" +
								"\t" + "carry_flag");
                    	   while (rs.next()) {
                        	
                        	System.out.println(rs.getString("account_id") + "\t" + rs.getString("line_id") +
                                    "\t" + rs.getString("lineseq_start_date") + "\t" + rs.getString("bc_start_date") +
                                    "\t" + rs.getString("accumulated_usage_kb") + "\t" + rs.getString("mno_mdn") +
        							"\t" + rs.getString("cbrs_imsi") + "\t" + rs.getString("threshold_50_reached") +
        							"\t" + rs.getString("threshold_80_reached") + "\t" + rs.getString("threshold_90_reached") +
        							"\t" + rs.getString("threshold_100_reached") + "\t" + rs.getString("threshold_50_date_notified") +
        							"\t" + rs.getString("threshold_80_date_notified") + "\t" + rs.getString("threshold_90_date_notified") +
									"\t" + rs.getString("threshold_100_date_notified") + "\t" + rs.getString("data_limit_kb") +
        							"\t" + rs.getString("carry_flag"));
                    	   }
                       	} 
						else if(tablename.contentEquals("subscriber_data_usage_mhs"))
                       {
							System.out.println("SUBSCRIBER USAGE MHS TABLE");
                    	   System.out.println("account_id" + "\t" + "line_id" +
                                "\t" + "lineseq_start_date" + "\t\t" + "bc_start_date" +
                                "\t\t" + "accumulated_usage_kb" + "\t" + "mno_mdn" +
    							"\t" + "cbrs_imsi" + "\t" + "threshold_50_reached" +
    							"\t" + "threshold_80_reached" + "\t" + "threshold_90_reached" +
    							"\t" + "threshold_100_reached" + "\t" + "threshold_50_date_notified" +
    							"\t" + "threshold_80_date_notified" + "\t" + "threshold_90_date_notified" +
    							"\t" + "threshold_100_date_notified" + "\t" + "data_limit_kb" +
								"\t" + "carry_flag");
                    	   while (rs.next()) {
                        	
                        	System.out.println(rs.getString("account_id") + "\t" + rs.getString("line_id") +
                                    "\t" + rs.getString("lineseq_start_date") + "\t" + rs.getString("bc_start_date") +
                                    "\t" + rs.getString("accumulated_usage_kb") + "\t" + rs.getString("mno_mdn") +
        							"\t" + rs.getString("cbrs_imsi") + "\t" + rs.getString("threshold_50_reached") +
        							"\t" + rs.getString("threshold_80_reached") + "\t" + rs.getString("threshold_90_reached") +
        							"\t" + rs.getString("threshold_100_reached") + "\t" + rs.getString("threshold_50_date_notified") +
        							"\t" + rs.getString("threshold_80_date_notified") + "\t" + rs.getString("threshold_90_date_notified") +
									"\t" + rs.getString("threshold_100_date_notified") + "\t" + rs.getString("data_limit_kb") +
        							"\t" + rs.getString("carry_flag"));
                    	   }
                       	} 
						else if(tablename.contentEquals("subscriber_data_usage_5g"))
                       {
							System.out.println("SUBSCRIBER USAGE 5G TABLE");
                    	   System.out.println("account_id" + "\t" + "line_id" +
                                "\t" + "lineseq_start_date" + "\t\t" + "bc_start_date" +
                                "\t\t" + "accumulated_usage_kb" + "\t" + "mno_mdn" +
    							"\t" + "cbrs_imsi" + "\t" + "threshold_50_reached" +
    							"\t" + "threshold_80_reached" + "\t" + "threshold_90_reached" +
    							"\t" + "threshold_100_reached" + "\t" + "threshold_50_date_notified" +
    							"\t" + "threshold_80_date_notified" + "\t" + "threshold_90_date_notified" +
    							"\t" + "threshold_100_date_notified" + "\t" + "data_limit_kb" +
								"\t" + "carry_flag");
                    	   while (rs.next()) {
                        	
                        	System.out.println(rs.getString("account_id") + "\t" + rs.getString("line_id") +
                                    "\t" + rs.getString("lineseq_start_date") + "\t" + rs.getString("bc_start_date") +
                                    "\t" + rs.getString("accumulated_usage_kb") + "\t" + rs.getString("mno_mdn") +
        							"\t" + rs.getString("cbrs_imsi") + "\t" + rs.getString("threshold_50_reached") +
        							"\t" + rs.getString("threshold_80_reached") + "\t" + rs.getString("threshold_90_reached") +
        							"\t" + rs.getString("threshold_100_reached") + "\t" + rs.getString("threshold_50_date_notified") +
        							"\t" + rs.getString("threshold_80_date_notified") + "\t" + rs.getString("threshold_90_date_notified") +
									"\t" + rs.getString("threshold_100_date_notified") + "\t" + rs.getString("data_limit_kb") +
        							"\t" + rs.getString("carry_flag"));
                    	   }
                       	}
						else if(tablename.contentEquals("jwt_token_info"))
	                    {
							System.out.println("JWT TOKEN TABLE");
	                    	System.out.println("db_token" + "\t" + "db_issue_time" +
	                                "\t" + "db_expiry_time" + "\t\t" + "db_istokenused" +
	                                "\t\t" + "db_iskeeploggedin" + "\t" + "db_userrole");
	                        while (rs.next()) {
	                        	
	                        	System.out.println(rs.getString("db_token") + "\t" + rs.getString("db_issue_time") +
	                                    "\t" + rs.getString("db_expiry_time") + "\t" + rs.getString("db_istokenused") +
	                                    "\t" + rs.getString("db_iskeeploggedin") + "\t" + rs.getString("db_userrole"));
	                        	}
	                    }
						else if(tablename.contentEquals("jwt_user_info"))
	                    {
							System.out.println("JWT USER TABLE");
	                    	System.out.println("db_userid" + "\t" + "db_username" +
	                                "\t" + "db_password" + "\t\t" + "db_userrole");
	                        while (rs.next()) {
	                        	
	                        	System.out.println(rs.getString("db_userid") + "\t" + rs.getString("db_username") +
	                                    "\t" + rs.getString("db_password") + "\t" + rs.getString("db_userrole"));
	                        	}
	                    } 
                } 
        	}
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }

      //  return rs;
    }
    
    public void deletefromTable(String url, Properties props, String query,String tablename) {
       // Connection conn = null;
       // props.setProperty("user","mmsuper");
		//props.setProperty("password","thule");
		//props.setProperty("ssl","false");
		//String sql = "DELETE FROM subscriber WHERE account_id = 'SAFH1111'";
        try (Connection conn = DriverManager.getConnection(url, props); 
        		Statement stmt = conn.createStatement();) {
              
        	stmt.executeUpdate(query);
            System.out.println("Record successfully deleted from table " + tablename);
            
            } catch (SQLException e) {
              e.printStackTrace();
            }
    }
    
    public void insertintoTable(String url, Properties props, String query,String tablename) {

        //props.setProperty("user","mmsuper");
 		//props.setProperty("password","thule");
 		//props.setProperty("ssl","false");
 		
 		try (Connection conn = DriverManager.getConnection(url, props); 
         		Statement stmt = conn.createStatement();) {
               
         	stmt.executeUpdate(query);
             System.out.println("Record successfully inserted into " + tablename);
             
             } catch (SQLException e) {
               e.printStackTrace();
             }
     }
    
}
